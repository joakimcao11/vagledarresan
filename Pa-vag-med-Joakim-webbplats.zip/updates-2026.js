// User-supplied career updates, 10 October 2026; original May CV remains a source.
(() => {
 const C=window.JOAKIM_CONTENT,V=window.JOAKIM_CV;
 V.originalPdf=V.pdf;V.pdf=C.cv.pdf='assets/CV-Joakim-Cao-kompletterat-oktober-2026.pdf';
 const biomes=['coast','garden','coast','river','coast','harbor','industrial','forest','river','garden','river','industrial','island','garden','mountain','birch','harbor','island','lake','island','harbor','harbor','coast','garden'];
 C.route.forEach((r,i)=>{const visualIndex=C.previousNordicRoute.indexOf(r.city);r.environment='city-'+visualIndex;r.biome=biomes[visualIndex];if(i>=2&&i<=4)r.mode='train';});
 C.currentWork=[
  ['Programledning och studievägledning','Programledning och studievägledning för studenter på civilingenjörsprogrammen i Datateknik och Informations- och kommunikationsteknik (InfoCom), samt mastervägledning för internationella masterstudenter.'],
  ['Industridesign och utbildningarnas kvalitet','Programledning och programutveckling inom kandidatprogrammet i industridesign samt medverkan i programledningar och utvecklingsarbete kopplat till utbildningarnas kvalitet och studenternas studiesituation.'],
  ['Karriärvägledning och övergången till arbetsliv','Karriärvägledning och karriärutveckling, bland annat genom arbete i en grupp för karriärfrågor samt undersöker utveckling av aktiviteter och insatser som stärker studenternas övergång från studier till arbetsliv.'],
  ['Utveckling av studie- och karriärvägledning','Utvecklingsarbete inom studie- och karriärvägledning, inklusive omvärldsbevakning, kompetensutveckling och pedagogisk utveckling för arbetsgruppen samt medverkan i planering och genomförande av SYV-dagen.'],
  ['VFU-handledning','Handledare för VFU-studenter som genomför sin verksamhetsförlagda utbildning inom studie- och karriärvägledningen vid LTH.']
 ];
 C.areas.push({id:'current-work',number:'07',icon:'people',title:'Min nuvarande arbetssituation',subtitle:'Programledning, vägledning och utveckling vid LTH.',color:'blue'});
 const role={id:'campus-helsingborg',years:'2025–2026',title:'Studie- och karriärvägledare',organization:'Campus Helsingborg, LTH, Lunds universitet',place:'Helsingborg',current:false,details:['Studie- och karriärvägledning för Högskoleingenjörsutbildning i Datateknik och Högskoleingenjörsutbildning i Elektroteknik med automationsteknik.','Period 2025–2026, enligt Joakims komplettering den 10 oktober 2026.']};
 V.roles.push(role);V.roles.find(r=>r.id==='lth').details=C.currentWork.map(t=>t[1]);V.updateDate='10 oktober 2026';
 const j={id:'campus-helsingborg-role',leg:2,position:35,kind:'role',ref:role.id,label:'Vägledning vid Campus Helsingborg',place:'Helsingborg · 2025–2026',actor:true,context:'Komplettering lämnad av Joakim den 10 oktober 2026.'};
 window.JOURNEY_DATA.push(j);
 const list=window.JOURNEY_DATA.filter(j=>j.leg===2);list.forEach((j,i)=>j.position=12+76*(i+.5)/list.length);
 C.route[2].note='Vid Campus Helsingborg, LTH, arbetade jag som studie- och karriärvägledare 2025–2026 för högskoleingenjörsutbildningarna i Datateknik och Elektroteknik med automationsteknik. Uppgiften är min komplettering från oktober 2026.';
})();
