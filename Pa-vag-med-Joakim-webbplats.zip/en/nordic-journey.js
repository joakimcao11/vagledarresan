// Route and encounters use the supplied CV and assignment lists; travel is illustrative.
(() => {
  const C=window.JOAKIM_CONTENT,S=window.SOURCE_DATA,V=window.JOAKIM_CV;
  const old=C.route.map(r=>r.city), original=window.JOURNEY_DATA;
  C.oldRoute=old;
  const rows=[
    ['Malmö','car','malmo'],['Lund','car','lund','methods'],
    ['Helsingborg','car','coast'],['Halmstad','car','coast'],['Varberg','car','coast'],
    ['Gothenburg','train','coast','perspectives'],['Borås','train','town'],['Skövde','train','town'],
    ['Karlstad','train','town'],['Linköping','train','town'],['Västerås','train','vasteras','partners'],
    ['Eskilstuna','train','town'],['Stockholm','train','stockholm','assignments'],['Uppsala','train','uppsala','services'],
    ['Luleå','plane','north','bio'],['Umeå','train','north'],['Sundsvall','train','north'],
    ['Vasa','plane','finland','nordic'],['Jyväskylä','train','finland'],['Helsinki','plane','helsinki','finland'],
    ['Karlskrona','train','coast'],['Copenhagen','boat','copenhagen','denmark'],['Nyborg','train','nyborg','nyborg'],
    ['Finish','walk','town','finish']
  ];
  C.route=rows.map(([city,mode,environment,area],i)=>({city,mode,environment,area:area||'city',country:i>=17&&i<=19?'Finland':i===21||i===22?'Denmark':i===23?'Your discoveries':'Sweden',note:city==='Copenhagen'?'We take an illustrated boat trip to Denmark. It is part of the story, rather than a record of an actual ferry service or Joakim’s means of transport.':`The next meeting is in ${city}. Open the city’s information stop or click on the people and signs.`}));
  const index=city=>C.route.findIndex(r=>r.city===city);
  const eventsCity=e=> {
    const t=e.title;
    for(const city of ['Copenhagen','Nyborg','Jyväskylä','Eskilstuna','Gothenburg','Stockholm','Uppsala','Lund','Malmö','Karlstad','Borås'])if(t.includes(city))return city;
    if(t.includes('Chalmers'))return 'Gothenburg';
    if(t.includes('Ultuna'))return 'Uppsala';
    if(t.includes('BTH'))return 'Karlskrona';
    return null;
  };
  const orgCity=o=>{
    const t=o.name;
    for(const city of ['Malmö','Lund','Helsingborg','Halmstad','Varberg','Gothenburg','Borås','Skövde','Karlstad','Linköping','Västerås','Stockholm','Uppsala','Sundsvall','Umeå','Luleå','Karlskrona'])if(t.includes(city))return city;
    return {'Mälardalen University':'Eskilstuna','SLU, Swedish University of Agricultural Sciences':'Uppsala','GR, Gothenburg Region':'Gothenburg'}[t]||null;
  };
  const items=original.map(j=>{
    const item={...j,leg:index(old[j.leg])};
    if(j.kind==='event'){
      const e=S.events.find(e=>e.title.includes(j.match)),city=eventsCity(e);
      if(city){item.leg=Math.max(1,index(city));item.context=undefined;}
    }
    return item;
  });
  for(const e of S.events){
    let j=items.find(j=>j.kind==='event'&&e.title.includes(j.match));
    const city=eventsCity(e), online=/online|webbinarium/i.test(e.title);
    const context=online?'An online meeting in the source material. Its placement in the journey is a reading and listening stop, rather than a physical conference venue.':!city?'The source material gives this assignment and year, but no location. Its position in the journey is a thematic reading stop.':e.title.includes('BTH')?'The source material names BTH for the conference. Karlskrona is a storytelling stop; the list does not give the exact conference venue.':undefined;
    if(!j){j={id:'source-'+e.id,leg:Math.max(1,index(city||'Stockholm')),kind:'event',match:e.title,label:e.title.split(',')[0],place:city?`${city} · ${e.year}`:`${online?'Online meeting':'Location not specified'} · ${e.year}`,actor:items.length%2===0};items.push(j);}
    j.sourceId=e.id;if(context)j.context=context;
  }
  for(const o of S.organizations){
    let j=items.find(j=>j.kind==='organization'&&S.organizations.find(candidate=>candidate.name===j.match||(!j.sourceId&&candidate.name.includes(j.match)))?.id===o.id);
    if(!j){const city=orgCity(o);j={id:'source-'+o.id,leg:Math.max(1,index(city||'Västerås')),kind:'organization',match:o.name,label:o.name,place:city||'Organisation stop',actor:true};items.push(j);}
    j.sourceId=o.id;j.context='The organisation is listed among professional development and workshop assignments. The year, exact venue, audience and format are not given. The city’s position in the journey provides context, rather than documenting a day of travel.';
  }
  // More career details from the CV, without assigning publications to event venues.
  for(const ref of ['police','technology','recruitment','editor']){
    const r=V.roles.find(r=>r.id===ref);if(r)items.push({id:'cv-role-'+ref,leg:ref==='editor'?index('Stockholm'):1,kind:'role',ref,label:r.title,place:r.organization,actor:true,context:ref==='editor'?'A national professional role. Stockholm is a thematic stop; the CV does not give a workplace location for this role.':undefined});
  }
  for(const ref of ['choices','summer'])if(!items.some(j=>j.kind==='publication'&&j.ref===ref))items.push({id:'cv-publication-'+ref,leg:1,kind:'publication',ref,label:V.publications.find(p=>p.id===ref).title,place:'Reading stop from the CV',actor:false});
  for(let leg=1;leg<C.route.length;leg++){const list=items.filter(j=>j.leg===leg);list.forEach((j,i)=>j.position=12+76*(i+.5)/list.length);}
  window.JOURNEY_DATA=items;
  const notes={
    'Malmö':'The journey begins here. My CV describes my work at Malmö University in 2018–2022, covering study and career guidance, student recruitment and development work. Read about Summer internships for boys and Vägledardagen 2025 too.',
    'Lund':'Since 2022 I have worked at LTH, Lund University. My CV includes master’s guidance, support for international students, widening recruitment, student ambassador training and supervision of guidance students.',
    'Gothenburg':'Here you will discover the GR labour market meeting 2026, Skolporten’s Guidance Conference 2024 and the Swedish engineering education development conference at Chalmers in 2024. Click to read about each assignment.',
    'Borås':'The 2022 information advisers’ day at the University of Borås appears in the conference list. The City of Borås and the University of Borås have also engaged me for professional development and workshops.',
    'Karlstad':'The 2022 Study Advisers’ Conference at Karlstad University is included in the source material. The university also appears among my consulting and training assignments.',
    'Eskilstuna':'SYV-dagen 2026 at Mälardalen University in Eskilstuna appears in the assignment list. Mälardalen University has also engaged me as a consultant and trainer.',
    'Stockholm':'Explore SETT, the Swedish Guidance Conference, Guidance Day, Guidance Calendar, Skolriks and UHR’s Kvalitetsdrivet. There are also thematic reading stops for national and online assignments without a specified location.',
    'Uppsala':'The source material includes the SKR labour market days 2025, NUAS Discover Together 2023 and the 2022 education conference at SLU in Ultuna. Explore the university and municipality stops too.',
    'Jyväskylä':'The IAEVG International Conference 2024 in Jyväskylä, Finland, is included in my source material. An international meeting about guidance, offering opportunities to share experiences across borders.',
    'Nyborg':'The Samba 13 conference 2025 in Nyborg, Denmark, is among my conference assignments. Take away a listening recommendation on visual support in study and career guidance too.',
    'Karlskrona':'Karlskrona Municipality is listed among professional development and workshop assignments. BTH’s Development Engineers’ Conference 2025 also appears in the source material, without an exact conference location.'
  };
  C.route.forEach(r=>{if(notes[r.city])r.note=notes[r.city];});
  C.underlagTopics=[
    ['Guidance, ethics and AI','How does AI affect the guidance profession? I explore opportunities and challenges, and professional, responsible and critical approaches as AI becomes part of everyday practice.'],
    ['Study strategies and completion','Students’ early experiences in higher education, early support, reflective conversations and a sense of belonging. Widening recruitment must be followed by conditions that help students thrive, complete their studies and succeed.'],
    ['AI, academic misconduct and learning in higher education','The difference between information, facts and knowledge, and how AI can support meaningful learning. The focus is on educational questions about students’ engagement, responsibility and understanding.'],
    ['Creative educational guidance methods','Process-oriented guidance in digital spaces, interactive tools and methods that make room for reflection, learning and hope for the future.'],
    ['Education and widening recruitment','Inclusion and motivation, studying as an investment, and how to engage more children and young adults in higher education, including health, care and education.'],
    ['Career learning and young adults','Young people’s future choices and a guidance process with meaning, direction and hope. Career learning as something we do, contributing to the development of individuals and society.'],
    ['Artificial intelligence and digitalisation','AI, chatbots, ChatGPT, digital media, visual support and creative tools in study and career guidance. Practical examples are combined with ethical and educational perspectives.']
  ];
  C.cityItems=i=>items.filter(j=>j.leg===Math.max(1,i));
  C.previousNordicRoute=C.route.map(r=>r.city);
  [C.previousNordicRoute[14],C.previousNordicRoute[16]]=[C.previousNordicRoute[16],C.previousNordicRoute[14]];
  C.restoreRouteIndex=(i,version)=>version>=3?i:index((version===2?C.previousNordicRoute:old)[i]);
  C.restoreCity=(saved)=>{const name=saved.routeVersion>=2?saved.cityName:old[saved.city];const found=index(name);return found>=0?found:0;};
})();
