// Redigera innehåll här. Uppdragslistorna ligger separat i source-data.js.
window.JOAKIM_CONTENT = {
  character: { standing: '../assets/joakim-wave-v2.png', walking: '../assets/joakim-walk-v2.png', seated: '../assets/joakim-seat-v2.png' },
  contact: { email: 'info@digicao.nu', phone:'0707801645', website: 'https://digicao.nu', network: 'https://vagledarlabbet.se', linkedin: 'https://www.linkedin.com/in/joakimcao/recent-activity/articles/' },
  cv: { pdf: '../assets/CV-Joakim-Cao-VT2026.pdf' },
  route: [
    {city:'Malmö',country:'Sweden',mode:'car',environment:'malmo',area:null,note:'Welcome aboard! We begin at home in Malmö and continue to Lund.'},
    {city:'Lund',country:'Sweden',mode:'car',environment:'lund',area:'methods',note:'Curious about how I work? Open the toolkit.'},
    {city:'Gothenburg',country:'Sweden',mode:'train',environment:'coast',area:'perspectives',note:'We are heading north. There is plenty to discover along the way.'},
    {city:'Stockholm',country:'Sweden',mode:'train',environment:'stockholm',area:'assignments',note:'Explore my assignments from 2021 to 2026 here.'},
    {city:'Västerås',country:'Sweden',mode:'train',environment:'vasteras',area:'partners',note:'Meeting different organisations brings fresh perspectives.'},
    {city:'Uppsala',country:'Sweden',mode:'train',environment:'uppsala',area:'services',note:'What would suit your organisation? Explore my services.'},
    {city:'Luleå',country:'Sweden',mode:'plane',environment:'north',area:'bio',note:'We take to the skies and continue our journey north.'},
    {city:'Vasa',country:'Finland',mode:'plane',environment:'finland',area:'nordic',note:'Guidance varies between countries. We have much to learn from one another.'},
    {city:'Helsinki',country:'Finland',mode:'train',environment:'helsinki',area:'finland',note:'Which perspectives will you take with you?'},
    {city:'Copenhagen',country:'Denmark',mode:'plane',environment:'copenhagen',area:'denmark',note:'New ideas often emerge through meetings and collaboration.'},
    {city:'Nyborg',country:'Denmark',mode:'train',environment:'nyborg',area:'nyborg',note:'One final stop to share experiences across the Nordic region.'},
    {city:'Finish',country:'Your discoveries',mode:'walk',environment:'town',area:'finish',note:'Thank you for joining the journey!'}
  ],
  areas: [
    {id:'methods',number:'01',icon:'tool',title:'My approach',subtitle:'Methods that make room for reflection.',color:'peach'},
    {id:'perspectives',number:'02',icon:'compass',title:'My perspectives',subtitle:'Guidance in a changing world.',color:'sage'},
    {id:'assignments',number:'03',icon:'mic',title:'Selected assignments',subtitle:'Conferences, workshops and talks.',color:'yellow'},
    {id:'partners',number:'04',icon:'people',title:'In good company',subtitle:'Organisations I have worked with.',color:'blue'},
    {id:'services',number:'05',icon:'spark',title:'My services',subtitle:'Find an approach that suits your organisation.',color:'peach'},
    {id:'bio',number:'06',icon:'person',title:'About me',subtitle:'Background, expertise and professional involvement.',color:'sage'}
  ],
  methods: [
    {id:'mi',title:'Motivational interviewing (MI)',what:'A conversational approach that explores motivation and a person’s own reasons for change.',practice:'One possible approach is to explore what the person wants to change and listen for their own reasons to take the next step.',where:'When a choice feels difficult or motivation needs to be explored.',draft:true},
    {id:'solution',title:'Solution-focused practice',what:'Focuses on resources, exceptions and small steps towards a desired situation.',practice:'One possible approach is to identify what already works and define a manageable next step.',where:'In conversations about goals, direction and change.',draft:true},
    {id:'coaching',title:'Coaching',what:'An exploratory conversation that makes room for personal goals, reflection and action.',practice:'One possible approach is to use questions, feedback and follow-up on the person’s own goals.',where:'When developing study strategies or preparing for new choices.',draft:true},
    {id:'process',title:'Process-oriented guidance',what:'Guidance can develop over time through repeated opportunities for reflection and learning.',practice:'My talks cover process-oriented guidance in digital spaces and career learning as something we actively do.',where:'When an organisation wants continuity in its guidance work.'},
    {id:'visual',title:'Creative and visual methods',what:'Images, visual support and interactive tools offer more ways to express and explore ideas.',practice:'Through DigiCao I offer creative educational tools for guidance professionals, coaches and educators.',where:'In individual meetings, group guidance and professional development.'},
    {id:'digilog',title:'Analogue, digital and AI-assisted guidance',what:'Digilog practice combines digital and analogue approaches.',practice:'Inspired by educator Helen Larsson, I combine digital and analogue methods in guidance conversations with young people and adults.',where:'In guidance conversations and learning processes where different forms of expression and tools complement one another.'},
    {id:'career',title:'Career learning',what:'Learning that helps people explore education, working life and their own opportunities.',practice:'My talks explore how guidance can become a process of meaning, direction and hope for the future.',where:'When supporting education and career choices among young people and adults.'}
  ],
  perspectives: [
    {id:'guidance',title:'Study and career guidance',text:'Conversations with young people and adults about future education and career choices.',example:'Explore alternatives, formulate questions and identify a next step.',link:'Practising study and career adviser at LTH, Lund University.'},
    {id:'learning',title:'Career learning and lifelong learning',text:'How guidance can strengthen learning, direction and hope throughout life.',example:'Make reflection an ongoing process rather than limiting it to a single conversation.',link:'Talk topics on career learning and young adults.'},
    {id:'ai',title:'Digitalisation and generative AI',text:'The opportunities and challenges of digital tools in guidance and education.',example:'Discuss an AI-generated answer in terms of ethics, relevance and professional judgement.',link:'Talks and workshops on AI, ChatGPT and digitalisation.'},
    {id:'justice',title:'Social justice and inclusion',text:'Meaningful learning processes that enable more people to participate and grow.',example:'Consider who an activity reaches and who needs other forms of support.',link:'Involvement in social justice, widening recruitment and participation.'},
    {id:'future',title:'The future of work',text:'What digitalisation and AI may mean for individuals, organisations and society.',example:'Explore how new technologies may affect professional roles and skills needs.',link:'DigiCao’s work on understanding the significance of digitalisation.'},
    {id:'education',title:'Education and working life',text:'Connections between learning, educational choices and opportunities in working life.',example:'Discuss educational options based on the person’s questions and goals.',link:'Expertise in education, work science and guidance.'},
    {id:'recruitment',title:'Widening recruitment',text:'More equal opportunities to apply for, participate in and complete higher education.',example:'Explore what might spark interest in higher education among underrepresented groups.',link:'Talks on young men’s interest in higher education and studying as an investment.'},
    {id:'choices',title:'Young people’s and adults’ choices',text:'Education and career choices as part of personal development.',example:'Make room for both uncertainty and curiosity when discussing the future.',link:'Guidance conversations and talks on meaning, motivation and hope for the future.'},
    {id:'pedagogy',title:'Educational development and learning',text:'Tools and methods that support reflection, engagement and learning.',example:'Combine visual support with practical exercises and reflective conversations.',link:'Educational supervision, creative tools and training activities.'}
  ],
  services: [
    {id:'talk',title:'Talks and inspiration sessions',text:'Perspectives and practical examples of guidance, AI and digitalisation.',audience:'Guidance professionals, educators, managers and conference organisers.',format:'Small or large groups, in person or online.',needs:['speaker','ai'],confirmed:true},
    {id:'workshop',title:'Workshops and professional development',text:'Practical work with creative methods and digital tools.',audience:'Study and career advisers, coaches and educators.',format:'A workshop or training activity tailored to the audience and purpose.',needs:['workshop','guidance','ai'],confirmed:true},
    {id:'syv',title:'Training for guidance professionals',text:'Develop guidance practice with modern technology and educational tools.',audience:'Practising guidance professionals and students training to become advisers.',format:'Talks, workshops and instructional videos.',needs:['guidance','workshop'],confirmed:true},
    {id:'ai',title:'Generative AI in practice',text:'Explore AI in guidance and education with an ethical and critical approach.',audience:'Guidance professionals, teachers and others working in education.',format:'Talk, workshop or consultation.',needs:['ai','speaker','workshop'],confirmed:true},
    {id:'tools',title:'Digital and educational tools',text:'Creative tools combining digital and analogue approaches.',audience:'Guidance professionals, coaches and educators.',format:'Tools, instructional videos, consultation and support.',needs:['tools','guidance'],confirmed:true},
    {id:'process',title:'Process support and organisational development',text:'Educational supervision and support for development work.',audience:'Groups and individuals in educational organisations.',format:'We will agree the approach and scope together.',needs:['guidance','tools'],confirmed:true},
    {id:'tailored',title:'Tailored training programmes',text:'All assignments are tailored to the audience, purpose, format and timeframe.',audience:'Organisations seeking an activity shaped around their own needs.',format:'A few hours, half a day, a full day or an agreed arrangement. A clear quotation in advance.',needs:['ai','guidance','speaker','workshop','tools'],confirmed:true}
  ],
  bio: {
    intro:'My name is Joakim Cao and I work with guidance, learning and development. I am a study and career adviser at LTH, Lund University, and an educational developer through DigiCao.',
    background:'My educational journey at Malmö University began with a degree in study and career guidance in 2017. In 2021 I completed a one-year master’s degree in education, focusing on career learning and transitions. In 2025 I added a two-year master’s degree in education, a one-year master’s degree in work science and a course in supervision.',
    competence:'Guidance, career learning, education, digitalisation and generative AI. At LTH I also work with student induction, placement supervision, student ambassador training, master’s guidance and strategic career support.',
    engagement:'I am involved in widening recruitment and participation, social justice, and learning among young people and adults. I am also an editor of Tidningen Vägledaren for the Swedish Association of Guidance Counsellors.',
    timeline:[{year:'2016–2018',text:'Guidance work at Merit utbildning AB and Peab AB, plus career coaching and recruitment at Jobbklar AB.'},{year:'2017',text:'Degree in study and career guidance from Malmö University.'},{year:'2018–2022',text:'Study and career guidance at Malmö University; also project management in widening recruitment, 2019–2022.'},{year:'2020–',text:'Educational developer, speaker and training consultant through DigiCao.'},{year:'2021',text:'One-year master’s degree in education, focusing on career learning and transitions.'},{year:'2022–',text:'Study and career adviser at LTH, Lund University.'},{year:'2023–',text:'Editor and writer for Tidningen Vägledaren, through the Swedish Association of Guidance Counsellors.'},{year:'2025',text:'Two-year master’s degree in education, one-year master’s degree in work science and supervision course at Malmö University.'},{year:'2026–',text:'Runs Vägledarlabbet, a network for guidance professionals.'}]
  }
};
