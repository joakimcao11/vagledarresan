// Faktauppgifter from CV-Joakim-Cao-VT2026.pdf, daterat May 2026.
window.JOAKIM_CV = {
  date:'May 2026', pdf:'../assets/CV-Joakim-Cao-VT2026.pdf',
  education:[
    {year:'2025',title:'Two-year master’s degree in education',credits:'120 ECTS credits',school:'Malmö University',detail:'Focus on educational sciences.'},
    {year:'2025',title:'One-year master’s degree in work science',credits:'60 ECTS credits',school:'Malmö University',detail:'Focus on career development.'},
    {year:'2025',title:'Supervision course',credits:'7.5 ECTS credits',school:'Malmö University',detail:'Guidance, supervision, feedback and communication.'},
    {year:'2021',title:'One-year master’s degree in education',credits:'60 ECTS credits',school:'Malmö University',detail:'Focus on career learning and transitions.'},
    {year:'2017',title:'Degree in study and career guidance',credits:'180 ECTS credits',school:'Malmö University',detail:'Received a scholarship from the Hildur Ljungdahl Scholarship Foundation in 2017.'}
  ],
  roles:[
    {id:'lth',years:'2022–',title:'Study and career adviser',organization:'Guidance and Support Unit, LTH, Lund University',place:'Lund',current:true,details:['Guidance for the MSc engineering programmes in Information and Communication Engineering, Computer Science and Engineering, and Engineering Physics, the bachelor’s programme in Industrial Design and master’s programmes.','Deputy coordinator for student induction and placement supervisor for guidance students.','Development of student ambassador training and widening recruitment initiatives.','Development of master’s guidance, support for international students and strategic career support for LTH students.']},
    {id:'digicao',years:'2020–',title:'Educational developer, speaker and training consultant',organization:'DigiCao',place:'Malmö · Lund · Distans',current:true,details:['Digitalisation, digital tools, career learning and artificial intelligence in study and career guidance.','Since 2026 I also run Vägledarlabbet, a network for guidance professionals.']},
    {id:'editor',years:'2023–',title:'Editor and writer',organization:'Swedish Association of Guidance Counsellors',place:null,current:true,details:['Tidningen Vägledaren, a magazine about education and working life.','Speaker and workshop facilitator at the national conference and the ethics council.']},
    {id:'police',years:'2021–2022',title:'Study and career adviser',organization:'Police Education Unit, Malmö University',place:'Malmö',current:false,details:[]},
    {id:'technology',years:'2019–2022',title:'Study and career adviser',organization:'Faculty of Technology and Society, Malmö University',place:'Malmö',current:false,details:[]},
    {id:'recruitment',years:'2019–2022',title:'Project manager for widening recruitment',organization:'Malmö University',place:'Malmö',current:false,details:[]},
    {id:'malmo',years:'2018–2022',title:'General study and career guidance',organization:'Malmö University',place:'Malmö',current:false,details:[]},
    {id:'jobbklar',years:'2017–2018',title:'Career coaching and recruitment',organization:'Jobbklar AB',place:null,current:false,details:[]},
    {id:'peab',years:'2016–2018',title:'Study and career adviser',organization:'Peab AB',place:null,current:false,details:[]},
    {id:'merit',years:'2016–2017',title:'Study and career adviser',organization:'Merit utbildning AB',place:null,current:false,details:[]}
  ],
  publications:[
    {id:'dropout',year:2025,title:'Beyond failure',subtitle:'A qualitative study of dropout in MSc engineering programmes',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-76425',text:'A study of dropout in MSc engineering programmes. Read the original for its findings and discussion.',themes:['Educational development','Study strategies']},
    {id:'summer',year:2022,title:'Summer internships for boys',subtitle:'A collaboration between Malmö University and the City of Malmö: project description and evaluation',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-53920',text:'Project description and evaluation of a collaboration between Malmö University and the City of Malmö.',themes:['Widening recruitment']},
    {id:'difference',year:2021,title:'To make a difference is to be the difference',subtitle:'A study of the significance of social networks for young adult men choosing higher education outside traditional gender patterns',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-40404',text:'A study of social networks and young adult men’s choices in higher education.',themes:['Widening recruitment','Career learning']},
    {id:'choices',year:2017,title:'“It will work out”',subtitle:'A study of introductory programme students’ thoughts about upper secondary school choices, future careers, and study and career guidance',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-28860',text:'A study of introductory programme students’ thoughts about upper secondary school choices, future careers and guidance.',themes:['Education and career choices']}
  ],
  media:[
    {id:'podcast',year:2024,type:'Podcast',title:'Who wants to talk to a robot?',organization:'Vägledningspodden',detail:'Episode 32 of Vägledningspodden: perspectives on guidance.',url:'https://poddtoppen.se/podcast/1500403445/vagledningspodden/avsnitt-32-vem-vill-prata-med-en-robot'},
    {id:'teachers',year:2024,type:'Recorded talk',title:'Use AI in your work as a guidance adviser',organization:'Swedish Teachers’ Union',detail:'Webinar from 2024. The link is included in Joakim’s CV.',url:'https://youtu.be/HX2VG94Mknw'},
    {id:'skolporten',year:2024,type:'Recorded talk',title:'How to use AI and digital tools in study and career guidance',organization:'Skolporten',detail:'Recording from the Skolporten conference in 2024.',url:'https://youtu.be/BrtZpzCzZFY'},
    {id:'ssr-ai',year:null,type:'Recorded talk',title:'AI and chatbots in study and career guidance',organization:'Akademikerförbundet SSR',detail:'The talk is listed in the CV. No year is given for the recording.',url:'https://youtu.be/miktyqKtlLk'},
    {id:'ssr-visual',year:null,type:'Recorded talk',title:'Visual support and digital tools in study and career guidance',organization:'Akademikerförbundet SSR',detail:'The talk is listed in the CV. No year is given for the recording.',url:'https://youtu.be/O-b1Sfx_13o'}
  ],
  articles:[
    {title:'Guidance is a human process, not an AI experiment',url:'https://www.vilarare.se/vi-vagledare/ai/vagledning-ar-en-mansklig-process-inte-ett-ai-experiment/'},
    {title:'Tidningen Vägledaren — collected articles',url:'https://drive.google.com/drive/folders/1JsyYYbJWEyqyJrp9UKlFfSY4TwHmDpiE?usp=sharing'},
    {title:'Articles on widening recruitment',url:'https://www.linkedin.com/in/joakimcao/recent-activity/articles/'},
    {title:'DigiSYV — newsletters and articles',url:'https://www.linkedin.com/newsletters/digisyv-nyhetsbrev-artiklar-7129141975206780928/'},
    {title:'Articles on careers and education',url:'https://www.linkedin.com/newsletters/7186024789642199040/'}
  ]
};
