window.JOAKIM_CONTENT.areas.push({id:'story',number:'08',icon:'book',title:'My story',subtitle:'From Malmö to the international stage.',color:'green'});
const updatedCityNotes={
 Stockholm:'Explore SETT, the Swedish Guidance Conference, Vägledardagen, Vägledarkalendariet, Skolriks and UHR’s Kvalitetsdrivet, alongside national and online assignments.',
 Karlskrona:'Explore professional development and workshops for Karlskrona Municipality, and read about BTH’s Development Engineers’ Conference 2025.',
 Copenhagen:'Join the boat trip to Denmark and discover my conference assignments and Nordic meetings in Copenhagen.'
};
window.JOAKIM_CONTENT.route.forEach(r=>{if(updatedCityNotes[r.city])r.note=updatedCityNotes[r.city];});
