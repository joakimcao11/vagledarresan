// User-supplied career updates, 10 October 2026; original May CV remains a source.
(() => {
 const C=window.JOAKIM_CONTENT,V=window.JOAKIM_CV;
 V.originalPdf=V.pdf;V.pdf=C.cv.pdf='../assets/CV-Joakim-Cao-kompletterat-oktober-2026.pdf';
 const biomes=['coast','garden','coast','river','coast','harbor','industrial','forest','river','garden','river','industrial','island','garden','mountain','birch','harbor','island','lake','island','harbor','harbor','coast','garden'];
 C.route.forEach((r,i)=>{const visualIndex=C.previousNordicRoute.indexOf(r.city);r.environment='city-'+visualIndex;r.biome=biomes[visualIndex];if(i>=2&&i<=4)r.mode='train';});
 C.currentWork=[
  ['Programme management and study guidance','Programme management and study guidance for students in the MSc engineering programmes in Computer Science and Engineering and Information and Communication Engineering (InfoCom), together with guidance for international master’s students.'],
  ['Industrial design and educational quality','Programme management and development within the bachelor’s programme in Industrial Design, and participation in programme teams and development work relating to educational quality and students’ study situations.'],
  ['Career guidance and the transition to employment','Career guidance and development, including work in a career-focused group and exploration of activities and initiatives that strengthen students’ transition from education to employment.'],
  ['Development of study and career guidance','Development work in study and career guidance, including monitoring developments in the field, professional and educational development for the team, and helping to plan and deliver SYV-dagen.'],
  ['Professional placement supervision','Supervisor for guidance students undertaking their professional placements in study and career guidance at LTH.']
 ];
 C.areas.push({id:'current-work',number:'07',icon:'people',title:'My current work',subtitle:'Programme management, guidance and development at LTH.',color:'blue'});
 const role={id:'campus-helsingborg',years:'2025–2026',title:'Study and career adviser',organization:'Campus Helsingborg, LTH, Lund University',place:'Helsingborg',current:false,details:['Study and career guidance for the BSc engineering programmes in Computer Engineering and Electrical Engineering with Automation Technology.','Period: 2025–2026, according to Joakim’s update of 10 October 2026.']};
 V.roles.push(role);V.roles.find(r=>r.id==='lth').details=C.currentWork.map(t=>t[1]);V.updateDate='10 October 2026';
 const j={id:'campus-helsingborg-role',leg:2,position:35,kind:'role',ref:role.id,label:'Guidance at Campus Helsingborg',place:'Helsingborg · 2025–2026',actor:true,context:'Update supplied by Joakim on 10 October 2026.'};
 window.JOURNEY_DATA.push(j);
 const list=window.JOURNEY_DATA.filter(j=>j.leg===2);list.forEach((j,i)=>j.position=12+76*(i+.5)/list.length);
 C.route[2].note='At Campus Helsingborg, LTH, I worked as a study and career adviser in 2025–2026 for the BSc engineering programmes in Computer Engineering and Electrical Engineering with Automation Technology. This information comes from my October 2026 update.';
})();
