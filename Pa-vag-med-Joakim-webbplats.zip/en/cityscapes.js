// Original stylised city illustrations, not photographic or geographically exact maps.
(() => {
 const A=window.JOAKIM_ART,C=window.JOAKIM_CONTENT,base=A.landscape;
 const palettes=[['#d6e8ef','#8baeba','#90aa83','#f6efdb'],['#efe8d6','#b4ba92','#86a87d','#b9af97'],['#e8dbe0','#9cbccc','#90a99a','#af8264'],['#e3eff0','#92bdc7','#a3bb89','#c68e73'],['#ede5d1','#a5c1c7','#a3ad83','#a2957b'],['#d2e2e7','#85a9b5','#7e9e83','#b67864'],['#e4ddd6','#acb8b4','#869c7e','#bd8a70'],['#dae8d3','#a6beb2','#698e75','#d7c4a6'],['#f0e8d2','#8abac5','#8ab08a','#d4b878'],['#ede4d0','#b5c8be','#9aaf86','#c2a58b'],['#dfe8e0','#8eafb6','#98ac85','#af7e63'],['#dedfd3','#94b7ba','#7e9983','#b78163'],['#dfe7ee','#8aafbd','#9fb298','#c29572'],['#efe3d7','#9ebfb7','#8ca27c','#ae765d'],['#dddbe5','#a6b7c7','#8ca19a','#bfa9a0'],['#e4eedf','#9cbfc4','#93b597','#dccdc0'],['#d0e6ed','#91bec9','#789995','#b7c9c3'],['#e3ecdf','#9bbfc9','#8ca99a','#bc967c'],['#dde4ef','#94b8c8','#718f80','#c3b091'],['#e1e8ea','#96bbc7','#9dae9b','#edeadb'],['#e9e2d1','#8eb5c5','#8eab96','#c5b483'],['#e6e4dd','#97bac7','#8fb59c','#dfb46c'],['#e7eacb','#97bcbf','#8dad85','#b77f68'],['#f3e8c9','#c4d6c2','#8fba92','#ebcb83']];
 const line='#38584c';
 const windows=(x,y,cols,rows,step=24)=>Array.from({length:cols*rows},(_,i)=>`<rect x="${x+i%cols*step}" y="${y+Math.floor(i/cols)*step}" width="12" height="17" rx="1" fill="#fff5dc"/>`).join('');
 const house=(x,y,w,h,color,roof=false)=>`<g stroke="${line}" stroke-width="2"><rect x="${x}" y="${y-h}" width="${w}" height="${h}" fill="${color}"/>${roof?`<path d="M${x-5} ${y-h}l${w/2+5}-${w*.4} ${w/2+5} ${w*.4}Z" fill="#786855"/>`:''}${windows(x+12,y-h+15,Math.max(1,Math.floor((w-20)/24)),Math.max(1,Math.floor((h-35)/24)))}<path d="M${x+w/2-9} ${y}v-28h18v28" fill="${line}"/></g>`;
 const tree=(x,y,birch=false,pine=false)=>`<g transform="translate(${x} ${y})"><path d="M0 0v-85" stroke="${birch?'#f9f5eb':line}" stroke-width="${birch?8:4}"/>${pine?'<path d="m0-150-35 66h18l-35 44h104L17-84h18Z" fill="#4e7865"/>':'<ellipse cx="0" cy="-93" rx="34" ry="43" fill="#9fba8a"/><circle cx="-16" cy="-81" r="25" fill="#afc693"/>'}${birch?'<path d="M-4-15h8m-8-23h8m-8-26h8" stroke="#526e60" stroke-width="3"/>':''}</g>`;
 const tower=(h,color,spire=false)=>`<path d="M-30 0v-${h}h60V0" fill="${color}" stroke="${line}" stroke-width="3"/>${spire?`<path d="m-36-${h} 36-85 36 85Z" fill="#4b776b"/>`:''}${windows(-19,-h+22,2,Math.floor((h-35)/32),30)}`;
 const cathedral=(color,spire=true)=>`<g transform="translate(-100 0)">${tower(190,color,spire)}</g><g transform="translate(100 0)">${tower(190,color,spire)}</g>${house(-72,0,144,128,color,true)}<circle cy="-98" r="19" fill="#e7dac4" stroke="${line}" stroke-width="3"/>`;
 function landmark(i){switch(i){
 case 0:return Array.from({length:10},(_,n)=>`<g transform="translate(${n*2-10} ${-n*25}) skewX(${n*2-8})"><rect x="-38" y="-24" width="76" height="23" fill="#f4f2e8" stroke="#688f83" stroke-width="2"/><path d="M-26-17h48m-48 9h48" stroke="#95b4ac" stroke-width="3"/></g>`).join('');
 case 1:return cathedral('#bdb49d',false);
 case 2:return `<path d="M-110 0h220l-40-50H-70Z" fill="#7a9b79"/><path d="M-45-25v-215h90v215Z" fill="#b2886c" stroke="${line}" stroke-width="3"/><path d="M-45-240v-20h16v14h22v-14h16v14h20v-14h16v20" fill="#b2886c" stroke="${line}" stroke-width="3"/>${windows(-30,-215,2,5,34)}<path d="M-130 0h260" stroke="#dcc9ac" stroke-width="12"/>`;
 case 3:return `<path d="M-210-20h420v30h-420Z" fill="#d2b398" stroke="${line}" stroke-width="3"/><g fill="#90bdc6">${[-150,-50,50,150].map(x=>`<path d="M${x-30} 10v-12a30 35 0 0 1 60 0v12Z"/>`).join('')}</g><g transform="translate(70 -42)">${house(-70,0,140,95,'#d4b27e',true)}</g>`;
 case 4:return `<path d="M-175 0v-100l60-25h230l60 25V0Z" fill="#adad94" stroke="${line}" stroke-width="3"/><path d="M-178-100h356M-175 0h350" stroke="#766f5b" stroke-width="8"/><g transform="translate(95 -100)">${tower(90,'#aa927a')}</g><path d="M-20 0v-38a20 20 0 0 1 40 0V0" fill="#586759"/>`;
 case 5:return `<path d="M-160 0V-210m0 10 120-55M-145-170h160m-15-85v100M100 0v-140m0-130 115 65m-120-10h125" stroke="#557d78" stroke-width="8" fill="none"/><path d="M-230 5h430l-50 35h-325Z" fill="#b8876e"/><g transform="translate(160 0)">${tower(145,'#eee8da')}</g><path d="M130-145v-50l60 20v45" fill="#b96e60"/>`;
 case 6:return `${house(-200,0,150,112,'#b5785c')}${house(-45,0,180,150,'#bc977b')}<path d="M-45-150l30-28 30 28 30-28 30 28 30-28 30 28" fill="#678d89" stroke="${line}" stroke-width="3"/><path d="M155 0v-260h32V0" fill="#af7964"/><path d="M157-261q-15-18 0-36" stroke="#f9f5e8" stroke-width="15" opacity=".8"/>`;
 case 7:return `<path d="M-270 0q160-250 320-170t240 130V0Z" fill="#77967e"/><path d="M-180-140q100-140 220-36" fill="#a3ba99"/>${tree(-130,0,false,true)}${tree(50,0,false,true)}${house(95,0,90,100,'#dbc6a9',true)}`;
 case 8:return `${house(-170,0,290,105,'#dcc17a')}<path d="m-180-105 40-45h210l60 45Z" fill="#627e6d"/><g transform="translate(130 0)">${tower(160,'#cfb279',true)}</g><path d="M-35-111v-52h40v52" fill="#ddbd74"/>`;
 case 9:return cathedral('#c4b091',true)+`<path d="M0-140v-200" stroke="${line}" stroke-width="8"/><path d="m-30-240 30-105 30 105" fill="#4d7165"/>`;
 case 10:return `${cathedral('#a87860',true)}<path d="M-210 30h420" stroke="#e4ddc4" stroke-width="12"/>`;
 case 11:return `${house(-160,0,180,105,'#ae725b')}${house(25,0,150,145,'#ba8a6b')}<path d="M-160-105l40-25 40 25 40-25 40 25M20-145l50-25 50 25 50-25" fill="#739b91"/><g transform="translate(155 -140)">${tower(85,'#af715b')}</g><path d="M-220 35h440" stroke="#dae9e7" stroke-width="5"/>`;
 case 12:return `${house(-195,0,340,130,'#b7876c')}<g transform="translate(140 0)">${tower(245,'#b8896b')}<path d="M-32-245l32-42 32 42Z" fill="#6d9a88"/><path d="M0-287v-20" stroke="#ad8d4f" stroke-width="6"/><circle cy="-207" r="12" fill="#efe1b9"/></g>`;
 case 13:return cathedral('#aa715f',true)+`<path d="M-200 15h400" stroke="#dcd3b4" stroke-width="9"/>`;
 case 14:return [-160,-55,50].map((x,n)=>house(x,0,100,130+n*27,['#c8ae9c','#d1b693','#b7a6a1'][n],true)).join('')+'<path d="M-240 35h460" stroke="#e6e7da" stroke-width="8"/>';
 case 15:return `${house(-140,0,270,110,'#d7c8b8',true)}${tree(-205,0,true)}${tree(190,0,true)}<path d="M-230 20h460" stroke="#d6e9e3" stroke-width="5"/>`;
 case 16:return `<path d="M-260 15h480l-50 35h-365Z" fill="#809e9f"/><path d="M-20 0v-80h130l50 80Z" fill="#e6e9de"/><path d="M-125-20v-110m-5-80 100 60m-90-30h115m-5-30v110" stroke="#597e80" stroke-width="8"/>${house(195,0,85,92,'#bdcfc7',true)}`;
 case 17:return `${house(-100,0,200,130,'#bc9a80',true)}<g transform="translate(0 -130)">${tower(85,'#b48e76')}</g><circle cy="-192" r="12" fill="#f4e8c9"/>${tree(-200,0,false,true)}${tree(210,0,false,true)}`;
 case 18:return `<path d="M-300 0q80-110 145-65t140-25 190 60V50H-300Z" fill="#799983"/>${house(-70,-20,140,70,'#d0b79c',true)}${tree(-180,0,false,true)}${tree(140,0,false,true)}<path class="water-glint" d="M-200 30h320m-250 20h190" stroke="#f6f2df" stroke-width="4"/>`;
 case 19:return `<path d="M-145 0v-100h290V0M-70-100v-45H70v45M-40-145v-35h80v35" fill="#eeeede" stroke="${line}" stroke-width="3"/><path d="M-40-180a40 44 0 0 1 80 0" fill="#85a68e"/><path d="M0-224v-20m-10 8h20" stroke="${line}" stroke-width="3"/><path d="M-70-80v80m35-80v80m35-80v80m35-80v80m35-80v80" stroke="#d1d7c5" stroke-width="10"/>`;
 case 20:return `${house(-145,0,235,95,'#cbb98d',true)}<g transform="translate(90 0)">${tower(160,'#c7b18a',true)}</g><path d="M-240 25h150l-20 25h-110Z" fill="#385e55"/><path d="M-170 25v-105l45 90h-45" fill="#eee9d2"/>`;
 case 21:return ['#deb268','#b87868','#83b39e','#d9c39e','#a26d60'].map((col,n)=>house(-210+n*86,0,80,120+n%2*35,col,true)).join('')+'<path d="M-170 35h270l-35 30h-205Z" fill="#3c675b"/>';
 case 22:return `${house(-150,0,250,120,'#b57f67',true)}<g transform="translate(125 0)">${tower(155,'#b7856f',true)}</g><path d="M-240 32h490" stroke="#e4ebe1" stroke-width="7"/>`;
 default:return `<path d="M-210 0V-160m420 160v-160" stroke="${line}" stroke-width="10"/><path d="M-210-160h420v70h-420Z" fill="#edcd8a" stroke="${line}" stroke-width="3"/><text x="0" y="-113" text-anchor="middle" fill="${line}" font-size="30" font-family="Segoe UI,sans-serif">TACK FÖR RESAN!</text>`;
 }}
 A.landscape=(env,hero=false,arrived=false)=>{
   if(!/^city-\d+$/.test(env))return base(env,hero,arrived);
   const i=Number(env.slice(5)),r=C.route.find(r=>r.environment===env),[sky,water,grass,stone]=palettes[i],biome=r.biome;
   const wet=['coast','harbor','river','island','lake'].includes(biome),wood=['forest','mountain','birch','lake'].includes(biome);
   let art=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2400 600" preserveAspectRatio="xMidYMid slice" data-city="${r.city}"><rect width="2400" height="600" fill="${sky}"/><circle cx="${260+i%4*155}" cy="${70+i%3*30}" r="${i%2?33:47}" fill="#f5d99e"/><path d="M0 310Q${120+i*8} ${wood?110:240} 370 300T850 290 1320 310 1900 270 2400 310V600H0Z" fill="${grass}" opacity=".6"/>`;
   if(wet)art+=`<path d="M0 340Q300 285 650 335T1300 320 1900 335 2400 300V550H0Z" fill="${water}"/><g class="water-glint" stroke="#eff8ed" stroke-width="3">${Array.from({length:16},(_,n)=>`<path d="M${n*152} ${360+n%4*26}h${55+n%3*22}"/>`).join('')}</g>`;
   if(biome==='coast')art+='<path d="M0 440q200-90 430-20t490-20 520 15 510-35 450 20v200H0Z" fill="#e2d4ac"/>';
   if(biome==='island')art+=`<g fill="${grass}"><ellipse cx="180" cy="372" rx="120" ry="27"/><ellipse cx="1500" cy="355" rx="150" ry="25"/></g>`;
   if(!wood)for(let n=0;n<12;n++)if(n%6!==2&&n%6!==3)art+=house(n*203,390,80+i%3*14,65+(n+i)%4*25,n%2?stone:'#eadbc3',i%3===0);
   for(const x of (arrived?[1000,2050]:[350,1180,2050]))art+=`<g class="city-silhouette" transform="translate(${x} 392)">${landmark(i)}</g>`;
   art+=`<path d="M0 450q200-18 450-8t450-3 500 4 500-10 500 4v165H0Z" fill="${grass}"/>`;
   for(let n=0;n<(wood?17:8);n++)art+=tree(90+n*(wood?143:310),460+(n%2)*12,biome==='birch',wood&&biome!=='birch');
   if(biome==='industrial')art+='<path d="M130 495h185m90 0h140m105 0h140" stroke="#708b80" stroke-width="7"/>';
   if(biome==='garden')art+=`<g fill="${i%2?'#d4a8af':'#edce7e'}">${Array.from({length:18},(_,n)=>`<circle cx="${n*129+44}" cy="${486+n%3*5}" r="6"/>`).join('')}</g>`;
   return art+'</svg>';
 };
 A.cityPalette=i=>palettes[Number(C.route[i].environment.slice(5))];
})();
