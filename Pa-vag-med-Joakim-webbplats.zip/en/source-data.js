window.SOURCE_DATA = {
  "events": [
    {
      "id": "event-0",
      "year": 2026,
      "title": "NUVAS Forum 2026, Copenhagen, Denmark",
      "type": "Conference / event"
    },
    {
      "id": "event-1",
      "year": 2026,
      "title": "GR labour market meeting 2026, Gothenburg",
      "type": "Conference / event"
    },
    {
      "id": "event-2",
      "year": 2026,
      "title": "Vejlederkonferencen 2026, Copenhagen, Denmark",
      "type": "Conference / event"
    },
    {
      "id": "event-3",
      "year": 2026,
      "title": "SETT fair 2026, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-4",
      "year": 2026,
      "title": "Swedish Association of Guidance Counsellors – webinar with the ethics council, 2026",
      "type": "Conference / event"
    },
    {
      "id": "event-5",
      "year": 2026,
      "title": "Skolporten Guidance Conference 2026, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-6",
      "year": 2026,
      "title": "Guidance Advisers’ Day 2026, Mälardalen University, Eskilstuna",
      "type": "Conference / event"
    },
    {
      "id": "event-7",
      "year": 2025,
      "title": "Swedish Guidance Conference 2025, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-8",
      "year": 2025,
      "title": "Guidance Day 2025, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-9",
      "year": 2025,
      "title": "Guidance Calendar 2025, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-10",
      "year": 2025,
      "title": "Labour market days via SKR 2025, Uppsala",
      "type": "Conference / event"
    },
    {
      "id": "event-11",
      "year": 2025,
      "title": "Skåne Guidance Advisers’ Day 2025, Lund",
      "type": "Conference / event"
    },
    {
      "id": "event-12",
      "year": 2025,
      "title": "Development Engineers’ Conference 2025, BTH",
      "type": "Conference / event"
    },
    {
      "id": "event-13",
      "year": 2025,
      "title": "Samba 13-konferencen 2025, Nyborg, Denmark",
      "type": "Conference / event"
    },
    {
      "id": "event-14",
      "year": 2025,
      "title": "Skolriks 2025, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-15",
      "year": 2025,
      "title": "SETT fair 2025, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-16",
      "year": 2025,
      "title": "Skolverket 2025",
      "type": "Conference / event"
    },
    {
      "id": "event-17",
      "year": 2025,
      "title": "SYV-Skåne network day 2025",
      "type": "Conference / event"
    },
    {
      "id": "event-18",
      "year": 2025,
      "title": "Guidance Day, Malmö University 2025",
      "type": "Conference / event"
    },
    {
      "id": "event-19",
      "year": 2024,
      "title": "IAEVG International Conference 2024, Jyväskylä, Finland",
      "type": "Conference / event"
    },
    {
      "id": "event-20",
      "year": 2024,
      "title": "UHR:s Quality-driven-konferens 2024, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-21",
      "year": 2024,
      "title": "Skolporten Guidance Conference 2024, Gothenburg",
      "type": "Conference / event"
    },
    {
      "id": "event-22",
      "year": 2024,
      "title": "Swedish Guidance Conference 2024, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-23",
      "year": 2024,
      "title": "Akademikerförbundet SSR 2024",
      "type": "Conference / event"
    },
    {
      "id": "event-24",
      "year": 2024,
      "title": "Conference for study advisers at Swedish universities and university colleges 2024",
      "type": "Conference / event"
    },
    {
      "id": "event-25",
      "year": 2024,
      "title": "SiV — study advisers in adult education 2024",
      "type": "Conference / event"
    },
    {
      "id": "event-26",
      "year": 2024,
      "title": "Swedish Teachers’ Union 2024",
      "type": "Conference / event"
    },
    {
      "id": "event-27",
      "year": 2024,
      "title": "Development conference for Swedish engineering education 2024, Chalmers",
      "type": "Conference / event"
    },
    {
      "id": "event-28",
      "year": 2023,
      "title": "SiV — adult education advisers’ network 2023",
      "type": "Conference / event"
    },
    {
      "id": "event-29",
      "year": 2023,
      "title": "NUAS Discover Together Conference 2023, Uppsala",
      "type": "Conference / event"
    },
    {
      "id": "event-30",
      "year": 2023,
      "title": "Swedish Guidance Conference 2023, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-31",
      "year": 2022,
      "title": "Study Advisers’ Conference 2022, Karlstad University",
      "type": "Conference / event"
    },
    {
      "id": "event-32",
      "year": 2022,
      "title": "Information Advisers’ Day 2022, University of Borås",
      "type": "Conference / event"
    },
    {
      "id": "event-33",
      "year": 2022,
      "title": "Swedish Guidance Conference 2022, online",
      "type": "Conference / event"
    },
    {
      "id": "event-34",
      "year": 2022,
      "title": "Education Conference 2022, SLU, Ultuna",
      "type": "Conference / event"
    },
    {
      "id": "event-35",
      "year": 2022,
      "title": "Guidance Calendar 2022, Stockholm",
      "type": "Conference / event"
    },
    {
      "id": "event-36",
      "year": 2021,
      "title": "Swedish Guidance Conference 2021, online",
      "type": "Conference / event"
    }
  ],
  "organizations": [
    {
      "id": "org-0",
      "name": "AcadeMedia Vägledning",
      "type": "Organisations and companies"
    },
    {
      "id": "org-1",
      "name": "Akademi Norr",
      "type": "Organisations and companies"
    },
    {
      "id": "org-2",
      "name": "City of Borås",
      "type": "Municipalities"
    },
    {
      "id": "org-3",
      "name": "Campus Mölndal",
      "type": "Organisations and companies"
    },
    {
      "id": "org-4",
      "name": "Dalavux",
      "type": "Organisations and companies"
    },
    {
      "id": "org-5",
      "name": "Falkenberg Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-6",
      "name": "Familjen Helsingborg",
      "type": "Organisations and companies"
    },
    {
      "id": "org-7",
      "name": "GR, Gothenburg Region",
      "type": "Organisations and companies"
    },
    {
      "id": "org-8",
      "name": "City of Gothenburg",
      "type": "Municipalities"
    },
    {
      "id": "org-9",
      "name": "University of Gothenburg",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-10",
      "name": "City of Halmstad",
      "type": "Municipalities"
    },
    {
      "id": "org-11",
      "name": "HejSYV AB",
      "type": "Organisations and companies"
    },
    {
      "id": "org-12",
      "name": "City of Helsingborg",
      "type": "Municipalities"
    },
    {
      "id": "org-13",
      "name": "Joint Faculties of Humanities and Theology, Lund University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-14",
      "name": "University of Borås",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-15",
      "name": "University of Skövde",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-16",
      "name": "Karlshamn Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-17",
      "name": "Karlskronas kommun",
      "type": "Municipalities"
    },
    {
      "id": "org-18",
      "name": "Karlstad University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-19",
      "name": "Kungsbacka Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-20",
      "name": "Laholm Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-21",
      "name": "Linköping University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-22",
      "name": "LTH, Lund University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-23",
      "name": "Luleå Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-24",
      "name": "Lund University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-25",
      "name": "City of Malmö: compulsory school, upper secondary and adult education, and labour market and social services departments",
      "type": "Municipalities"
    },
    {
      "id": "org-26",
      "name": "Malmö University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-27",
      "name": "Manpower Matchning",
      "type": "Organisations and companies"
    },
    {
      "id": "org-28",
      "name": "Faculty of Medicine, Lund University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-29",
      "name": "Mälardalen University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-30",
      "name": "City of Mölndal",
      "type": "Municipalities"
    },
    {
      "id": "org-31",
      "name": "Olofström Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-32",
      "name": "Omställningsfonden",
      "type": "Organisations and companies"
    },
    {
      "id": "org-33",
      "name": "Piteå Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-34",
      "name": "Region Blekinge",
      "type": "Regions"
    },
    {
      "id": "org-35",
      "name": "Region Dalarna",
      "type": "Regions"
    },
    {
      "id": "org-36",
      "name": "Region Skåne",
      "type": "Regions"
    },
    {
      "id": "org-37",
      "name": "Region Sörmland",
      "type": "Regions"
    },
    {
      "id": "org-38",
      "name": "Region Östergötland",
      "type": "Regions"
    },
    {
      "id": "org-39",
      "name": "Ronneby Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-40",
      "name": "Municipalities of Skåne",
      "type": "Municipalities"
    },
    {
      "id": "org-41",
      "name": "SLU, Swedish University of Agricultural Sciences",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-42",
      "name": "City of Stockholm",
      "type": "Municipalities"
    },
    {
      "id": "org-43",
      "name": "Stockholm University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-44",
      "name": "Sundsvall Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-45",
      "name": "Sölvesborg Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-46",
      "name": "Umeå Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-47",
      "name": "Uppsala University",
      "type": "Universities and university colleges"
    },
    {
      "id": "org-48",
      "name": "Uppsalas kommun",
      "type": "Municipalities"
    },
    {
      "id": "org-49",
      "name": "Vara Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-50",
      "name": "Varberg Municipality",
      "type": "Municipalities"
    },
    {
      "id": "org-51",
      "name": "City of Västerås adult education",
      "type": "Municipalities"
    }
  ],
  "lectureThemes": {
    "Digitalisation and AI": [
      "AI for study and career guidance in municipal adult education",
      "AI and chatbots for study and career advisers",
      "AI and ChatGPT in study and career guidance",
      "AI in guidance",
      "AI with school staff",
      "Digital hope — supporting hope and active engagement across distance",
      "Digital media and ethics in study and career guidance",
      "E-guidance, ICT in guidance and interactive guidance",
      "Creative guidance methods and development in guidance",
      "How to use AI in guidance work",
      "How to use visual support and digital tools in study and career guidance",
      "Process-oriented guidance in digital spaces",
      "Using digital technologies and creative approaches in career guidance counselling",
      "Visual support and digital tools in study and career guidance"
    ],
    "Widening recruitment": [
      "Engaging young men in higher education",
      "Seeing study as an investment",
      "Summer internships for boys — engaging young men in higher education in health, care and education"
    ],
    "Career learning and young adults": [
      "Awakening motivation — when guidance becomes a process of meaning, direction and hope",
      "How can we help more young people and adults contribute to society and meet skills needs?",
      "Talking about career learning and young adults",
      "What happens when study and career guidance becomes something we do, rather than just receive?"
    ]
  }
};
