// Route and encounters use the supplied CV and assignment lists; travel is illustrative.
(() => {
  const C=window.JOAKIM_CONTENT,S=window.SOURCE_DATA,V=window.JOAKIM_CV;
  const old=C.route.map(r=>r.city), original=window.JOURNEY_DATA;
  C.oldRoute=old;
  const rows=[
    ['Malmö','car','malmo'],['Lund','car','lund','methods'],
    ['Helsingborg','car','coast'],['Halmstad','car','coast'],['Varberg','car','coast'],
    ['Göteborg','train','coast','perspectives'],['Borås','train','town'],['Skövde','train','town'],
    ['Karlstad','train','town'],['Linköping','train','town'],['Västerås','train','vasteras','partners'],
    ['Eskilstuna','train','town'],['Stockholm','train','stockholm','assignments'],['Uppsala','train','uppsala','services'],
    ['Luleå','plane','north','bio'],['Umeå','train','north'],['Sundsvall','train','north'],
    ['Vasa','plane','finland','nordic'],['Jyväskylä','train','finland'],['Helsingfors','plane','helsinki','finland'],
    ['Karlskrona','train','coast'],['Köpenhamn','boat','copenhagen','denmark'],['Nyborg','train','nyborg','nyborg'],
    ['Målgång','walk','town','finish']
  ];
  C.route=rows.map(([city,mode,environment,area],i)=>({city,mode,environment,area:area||'city',country:i>=17&&i<=19?'Finland':i===21||i===22?'Danmark':i===23?'Dina upptäckter':'Sverige',note:city==='Köpenhamn'?'Vi tar en illustrerad båttur till Danmark. Det är en del av berättelsen, inte en uppgift om en verklig färjelinje eller Joakims färdsätt.':`Nästa möte finns i ${city}. Öppna stadens informationsstopp eller klicka på deltagarna och skyltarna.`}));
  const index=city=>C.route.findIndex(r=>r.city===city);
  const eventsCity=e=> {
    const t=e.title;
    for(const city of ['Köpenhamn','Nyborg','Jyväskylä','Eskilstuna','Göteborg','Stockholm','Uppsala','Lund','Malmö','Karlstad','Borås'])if(t.includes(city))return city;
    if(t.includes('Chalmers'))return 'Göteborg';
    if(t.includes('Ultuna'))return 'Uppsala';
    if(t.includes('BTH'))return 'Karlskrona';
    return null;
  };
  const orgCity=o=>{
    const t=o.name;
    for(const city of ['Malmö','Lund','Helsingborg','Halmstad','Varberg','Göteborg','Borås','Skövde','Karlstad','Linköping','Västerås','Stockholm','Uppsala','Sundsvall','Umeå','Luleå','Karlskrona'])if(t.includes(city))return city;
    return {'Mälardalens universitet':'Eskilstuna','SLU, Sveriges lantbruksuniversitet':'Uppsala','GR, Göteborgsregionen':'Göteborg'}[t]||null;
  };
  const items=original.map(j=>{
    const item={...j,leg:index(old[j.leg])};
    if(j.kind==='event'){
      const e=S.events.find(e=>e.title.includes(j.match)),city=eventsCity(e);
      if(city){item.leg=Math.max(1,index(city));item.context=undefined;}
    }
    return item;
  });
  for(const e of S.events){
    let j=items.find(j=>j.kind==='event'&&e.title.includes(j.match));
    const city=eventsCity(e), online=/online|webbinarium/i.test(e.title);
    const context=online?'Ett digitalt möte i underlaget. Placeringen i resan är ett läs- och lyssningsstopp, inte en fysisk konferensplats.':!city?'Underlaget anger detta uppdrag och årtal, men ingen ort. Placeringen i resan är ett tematiskt lässtopp.':e.title.includes('BTH')?'Underlaget anger BTH för konferensen. Karlskrona är ett berättarstopp; exakt konferensort anges inte i listan.':undefined;
    if(!j){j={id:'source-'+e.id,leg:Math.max(1,index(city||'Stockholm')),kind:'event',match:e.title,label:e.title.split(',')[0],place:city?`${city} · ${e.year}`:`${online?'Digitalt möte':'Ort ej angiven'} · ${e.year}`,actor:items.length%2===0};items.push(j);}
    j.sourceId=e.id;if(context)j.context=context;
  }
  for(const o of S.organizations){
    let j=items.find(j=>j.kind==='organization'&&S.organizations.find(candidate=>candidate.name===j.match||(!j.sourceId&&candidate.name.includes(j.match)))?.id===o.id);
    if(!j){const city=orgCity(o);j={id:'source-'+o.id,leg:Math.max(1,index(city||'Västerås')),kind:'organization',match:o.name,label:o.name,place:city||'Verksamhetsstopp',actor:true};items.push(j);}
    j.sourceId=o.id;j.context='Organisationen finns med bland uppdragen inom kompetensutveckling och workshop. År, exakt lokal, målgrupp och upplägg för detta uppdrag anges inte i listan. Stadens placering i resan beskriver sammanhanget, inte en dokumenterad resdag.';
  }
  // More career details from the CV, without assigning publications to event venues.
  for(const ref of ['police','technology','recruitment','editor']){
    const r=V.roles.find(r=>r.id===ref);if(r)items.push({id:'cv-role-'+ref,leg:ref==='editor'?index('Stockholm'):1,kind:'role',ref,label:r.title,place:r.organization,actor:true,context:ref==='editor'?'Ett nationellt engagemang. Stockholm är ett tematiskt stopp; CV:t anger ingen arbetsort för denna roll.':undefined});
  }
  for(const ref of ['choices','summer'])if(!items.some(j=>j.kind==='publication'&&j.ref===ref))items.push({id:'cv-publication-'+ref,leg:1,kind:'publication',ref,label:V.publications.find(p=>p.id===ref).title,place:'Lässtopp ur CV:t',actor:false});
  for(let leg=1;leg<C.route.length;leg++){const list=items.filter(j=>j.leg===leg);list.forEach((j,i)=>j.position=12+76*(i+.5)/list.length);}
  window.JOURNEY_DATA=items;
  const notes={
    'Malmö':'Här börjar resan. Mitt CV beskriver arbetet vid Malmö universitet 2018–2022, med studie- och karriärvägledning, studentrekrytering och utvecklingsarbete. Läs också om Sommarpraktik för killar och Vägledardagen 2025.',
    'Lund':'Sedan 2022 arbetar jag vid LTH, Lunds universitet. I CV:t finns bland annat mastervägledning, stöd för internationella studenter, breddad rekrytering, studentambassadörsutbildning och handledning av SYV-studenter.',
    'Göteborg':'Här möter du Mötesplats arbetsmarknad GR 2026, Skolportens Vägledarkonferens 2024 och utvecklingskonferensen för Sveriges ingenjörsutbildning vid Chalmers 2024. Klicka för att läsa om respektive uppdrag.',
    'Borås':'Vidareinformatörsdagen 2022 vid Högskolan i Borås finns i konferenslistan. Borås stad och Högskolan i Borås finns också bland verksamheterna som anlitat mig för kompetensutveckling och workshop.',
    'Karlstad':'Studievägledarkonferensen 2022 vid Karlstads universitet finns i underlaget. Universitetet finns även med bland mina konsult- och utbildningsuppdrag.',
    'Eskilstuna':'SYV-dagen 2026 vid Mälardalens universitet i Eskilstuna finns i uppdragslistan. Mälardalens universitet finns också bland verksamheterna som anlitat mig som konsult och utbildare.',
    'Stockholm':'Utforska SETT, Sveriges Vägledarkonferens, Vägledardagen, Vägledarkalendariet, Skolriks och UHR:s Kvalitetsdrivet. Här finns också tematiska lässtopp för nationella och digitala uppdrag där underlaget inte anger en ort.',
    'Uppsala':'Arbetsmarknadsdagarna via SKR 2025, NUAS Discover Together 2023 och Utbildningskonferens 2022 vid SLU i Ultuna finns i underlaget. Utforska även universitetets och kommunens verksamhetsstopp.',
    'Jyväskylä':'IAEVG International Conference 2024 i Jyväskylä, Finland finns i mitt underlag. Ett internationellt möte kring vägledning, med möjligheter till erfarenhetsutbyte över landsgränser.',
    'Nyborg':'Samba 13-konferencen 2025 i Nyborg, Danmark finns bland mina konferensuppdrag. Ta också med dig ett lyssningstips om visuellt stöd i studie- och yrkesvägledning.',
    'Karlskrona':'Karlskrona kommun finns i listan över kompetensutveckling och workshops. BTH:s Utvecklingsingenjörskonferens 2025 finns också i underlaget, men exakt konferensort anges inte där.'
  };
  C.route.forEach(r=>{if(notes[r.city])r.note=notes[r.city];});
  C.underlagTopics=[
    ['Vägledning, etik och AI','Vad gör AI med vägledarprofessionen? Jag belyser möjligheter och utmaningar samt professionella, ansvarsfulla och kritiska förhållningssätt när AI blir en del av vardagen.'],
    ['Studiestrategier och genomströmning','Studenters första tid i högre utbildning, tidigt stöd, reflekterande samtal och social samhörighet. Breddad rekrytering behöver följas av förutsättningar att trivas, fullfölja och lyckas.'],
    ['AI, fusk och lärande i högre utbildning','Skillnaden mellan information, fakta och kunskap och hur AI kan stödja ett verkligt lärande. Fokus ligger på pedagogiska frågor om studenters engagemang, ansvar och förståelse.'],
    ['Kreativa och pedagogiska vägledningsmetoder','Processvägledning i digitala rum, interaktiva verktyg och arbetssätt som skapar utrymme för reflektion, lärande och framtidstro.'],
    ['Utbildningsfrågor och breddad rekrytering','Inkludering och motivation, studier som investering och hur fler barn och unga vuxna kan intresseras för högre studier, bland annat inom vård, omsorg och pedagogik.'],
    ['Karriärlärande och unga vuxna','Ungas framtidsval och en vägledningsprocess med mening, riktning och framtidstro. Karriärlärande som något vi gör och som bidrar till både individens och samhällets utveckling.'],
    ['Artificiell intelligens och digitalisering','AI, chattbotar, ChatGPT, digitala medier, visuellt stöd och kreativa verktyg i studie- och yrkesvägledning. Praktiska exempel förenas med etiska och pedagogiska perspektiv.']
  ];
  C.cityItems=i=>items.filter(j=>j.leg===Math.max(1,i));
  C.previousNordicRoute=C.route.map(r=>r.city);
  [C.previousNordicRoute[14],C.previousNordicRoute[16]]=[C.previousNordicRoute[16],C.previousNordicRoute[14]];
  C.restoreRouteIndex=(i,version)=>version>=3?i:index((version===2?C.previousNordicRoute:old)[i]);
  C.restoreCity=(saved)=>{const name=saved.routeVersion>=2?saved.cityName:old[saved.city];const found=index(name);return found>=0?found:0;};
})();
