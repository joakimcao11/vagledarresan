window.JOAKIM_CONTENT.areas.push({id:'story',number:'08',icon:'book',title:'Min story',subtitle:'Från Malmö till den internationella scenen.',color:'green'});
const updatedCityNotes={
 Stockholm:'Utforska SETT, Sveriges Vägledarkonferens, Vägledardagen, Vägledarkalendariet, Skolriks och UHR:s Kvalitetsdrivet, tillsammans med nationella och digitala uppdrag.',
 Karlskrona:'Utforska kompetensutveckling och workshops för Karlskrona kommun och läs om BTH:s Utvecklingsingenjörskonferens 2025.',
 Köpenhamn:'Följ med på båtturen till Danmark och upptäck mina konferensuppdrag och nordiska möten i Köpenhamn.'
};
window.JOAKIM_CONTENT.route.forEach(r=>{if(updatedCityNotes[r.city])r.note=updatedCityNotes[r.city];});
