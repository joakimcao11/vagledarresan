// A quieter journey: career, degrees and assignments, grouped by documented year.
(() => {
 const C=window.JOAKIM_CONTENT,V=window.JOAKIM_CV,S=window.SOURCE_DATA;
 const combined=['police','technology','recruitment'];
 const malmo=V.roles.find(r=>r.id==='malmo');
 malmo.details=combined.map(id=>{const r=V.roles.find(r=>r.id===id);return `${r.years} · ${r.title}, ${r.organization}.`;});
 let items=window.JOURNEY_DATA.filter(j=>['role','event','organization'].includes(j.kind)&&!combined.includes(j.ref)&&j.ref!=='editor').map(j=>({...j}));
 // Keep earlier employment in the career's Malmö starting chapter; CV locations remain unchanged.
 for(const ref of ['merit','peab','jobbklar']){const r=V.roles.find(r=>r.id===ref);items.push({id:'career-'+ref,leg:1,cityIndex:0,kind:'role',ref,label:r.organization,place:r.years,actor:false});}
 V.education.forEach((e,i)=>{if(e.title==='Handledarkurs')return;items.push({id:'degree-'+i,leg:1,cityIndex:0,kind:'education',ref:String(i),label:e.title,place:e.school+' · '+e.year,actor:false,year:Number(e.year)});});
 items.forEach(j=>{
  if(j.cityIndex===undefined)j.cityIndex=j.leg===1&&(j.kind==='role'&&j.ref!=='lth'||j.kind==='organization'&&j.match.includes('Malmö')||j.kind==='event'&&j.place.includes('Malmö'))?0:j.leg;
  j.leg=Math.max(1,j.cityIndex);
  if(j.kind==='event')j.year=S.events.find(e=>e.id===j.sourceId).year;
  if(j.kind==='role')j.year=Number(V.roles.find(r=>r.id===j.ref).years.match(/\d{4}/)?.[0])||null;
  if(j.kind==='organization')j.year=null;
  delete j.media;
 });
 for(let city=0;city<C.route.length;city++){
  const list=items.filter(j=>j.cityIndex===city).sort((a,b)=>(a.year??9999)-(b.year??9999)||a.label.localeCompare(b.label,'sv'));
  list.forEach((j,i)=>j.position=10+80*(i+.5)/list.length);
 }
 items.sort((a,b)=>a.cityIndex-b.cityIndex||(a.year??9999)-(b.year??9999)||a.position-b.position);
 window.JOURNEY_DATA=items;
 C.cityItems=i=>items.filter(j=>j.cityIndex===i);
 C.route[0].note='Här börjar min yrkesresa i Malmö. Utforska mina anställningar, examina och uppdrag i årsöversikten. Malmö universitet 2018–2022 samlar även mina roller inom teknik och samhälle, polisiärt arbete och breddad rekrytering.';
 C.route.find(r=>r.city==='Nyborg').note='Samba 13-konferencen 2025 i Nyborg, Danmark finns bland mina konferensuppdrag. Öppna konferensstoppet för att läsa mer.';
})();
