// Faktauppgifter från CV-Joakim-Cao-VT2026.pdf, daterat maj 2026.
window.JOAKIM_CV = {
  date:'Maj 2026', pdf:'assets/CV-Joakim-Cao-VT2026.pdf',
  education:[
    {year:'2025',title:'Master i pedagogik',credits:'120 hp',school:'Malmö universitet',detail:'Inriktning mot utbildningsvetenskap.'},
    {year:'2025',title:'Magister i arbetsvetenskap',credits:'60 hp',school:'Malmö universitet',detail:'Inriktning mot karriärutveckling.'},
    {year:'2025',title:'Handledarkurs',credits:'7,5 hp',school:'Malmö universitet',detail:'Vägledning, handledning, feedback och kommunikation.'},
    {year:'2021',title:'Magister i pedagogik',credits:'60 hp',school:'Malmö universitet',detail:'Inriktning mot karriärlärande och övergångar.'},
    {year:'2017',title:'Studie- och yrkesvägledarexamen',credits:'180 hp',school:'Malmö universitet',detail:'Mottog Hildur Ljungdahls Stipendiestiftelse 2017.'}
  ],
  roles:[
    {id:'lth',years:'2022–',title:'Studie- och karriärvägledare',organization:'Enheten för vägledning och stöd, LTH, Lunds universitet',place:'Lund',current:true,details:['Vägledning för civilingenjörsutbildningarna i Infocom, Datateknik och Teknisk fysik, kandidatutbildningen i industridesign och masterprogram.','Biträdande samordnare för akademisk mottagning och VFU-handledare för SYV-studenter.','Utveckling av studentambassadörsutbildning och breddade rekryteringsinsatser.','Utveckling av mastervägledning, stöd för internationella studenter och strategiskt karriärstöd för LTH-studenter.']},
    {id:'digicao',years:'2020–',title:'Pedagogisk utvecklare, föreläsare och utbildningskonsult',organization:'DigiCao',place:'Malmö · Lund · Distans',current:true,details:['Digitalisering, digitala verktyg, karriärlärande och artificiell intelligens i studie- och yrkesvägledning.','Sedan 2026 driver jag även Vägledarlabbet, ett nätverk för vägledare.']},
    {id:'editor',years:'2023–',title:'Redaktör och skribent',organization:'Sveriges Vägledarförening',place:null,current:true,details:['Tidningen Vägledaren i utbildning och arbetsliv.','Föreläsare och workshopshållare vid den nationella konferensen och det etiska rådet.']},
    {id:'police',years:'2021–2022',title:'Studie- och karriärvägledare',organization:'Enheten för polisiärt arbete, Malmö universitet',place:'Malmö',current:false,details:[]},
    {id:'technology',years:'2019–2022',title:'Studie- och karriärvägledare',organization:'Fakulteten för teknik och samhälle, Malmö universitet',place:'Malmö',current:false,details:[]},
    {id:'recruitment',years:'2019–2022',title:'Projektledare för breddad rekrytering',organization:'Malmö universitet',place:'Malmö',current:false,details:[]},
    {id:'malmo',years:'2018–2022',title:'Allmän studie- och karriärvägledning',organization:'Malmö universitet',place:'Malmö',current:false,details:[]},
    {id:'jobbklar',years:'2017–2018',title:'Karriärcoachning och rekrytering',organization:'Jobbklar AB',place:null,current:false,details:[]},
    {id:'peab',years:'2016–2018',title:'Studie- och yrkesvägledare',organization:'Peab AB',place:null,current:false,details:[]},
    {id:'merit',years:'2016–2017',title:'Studie- och yrkesvägledare',organization:'Merit utbildning AB',place:null,current:false,details:[]}
  ],
  publications:[
    {id:'dropout',year:2025,title:'Bortom misslyckande',subtitle:'En kvalitativ studie om studieavbrott inom civilingenjörsutbildning',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-76425',text:'Ett arbete om studieavbrott inom civilingenjörsutbildning. Läs originalet för studiens resultat och resonemang.',themes:['Pedagogisk utveckling','Studiestrategier']},
    {id:'summer',year:2022,title:'Sommarpraktik för killar',subtitle:'Ett samarbete mellan Malmö universitet och Malmö stad: projektbeskrivning och utvärdering',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-53920',text:'Projektbeskrivning och utvärdering av ett samarbete mellan Malmö universitet och Malmö stad.',themes:['Breddad rekrytering']},
    {id:'difference',year:2021,title:'Att göra skillnad är att vara skillnaden',subtitle:'En studie om det sociala nätverkets betydelse för några unga vuxna mäns könsbrytande val av högskoleutbildning',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-40404',text:'Ett arbete om sociala nätverk och unga vuxna mäns val av högskoleutbildning.',themes:['Breddad rekrytering','Karriärlärande']},
    {id:'choices',year:2017,title:'”Det löser sig”',subtitle:'En studie om introduktionselevers tankar om sitt gymnasieval, framtida karriär samt syn på studie- och yrkesvägledning',url:'https://urn.kb.se/resolve?urn=urn:nbn:se:mau:diva-28860',text:'Ett arbete om introduktionselevers tankar om gymnasieval, framtida karriär och vägledning.',themes:['Utbildnings- och yrkesval']}
  ],
  media:[
    {id:'podcast',year:2024,type:'Podcast',title:'Vem vill prata med en robot?',organization:'Vägledningspodden',detail:'Avsnitt 32 i Vägledningspodden – perspektiv på vägledning.',url:'https://poddtoppen.se/podcast/1500403445/vagledningspodden/avsnitt-32-vem-vill-prata-med-en-robot'},
    {id:'teachers',year:2024,type:'Inspelad föreläsning',title:'Använd AI i ditt arbete som SYV',organization:'Sveriges Lärare',detail:'Webbinarium 2024. Länken finns i Joakims CV.',url:'https://youtu.be/HX2VG94Mknw'},
    {id:'skolporten',year:2024,type:'Inspelad föreläsning',title:'Så kan du använda AI & digitala verktyg i studie- och yrkesvägledning',organization:'Skolporten',detail:'Inspelning från Skolportens konferens 2024.',url:'https://youtu.be/BrtZpzCzZFY'},
    {id:'ssr-ai',year:null,type:'Inspelad föreläsning',title:'AI och chatrobotar i studie- och yrkesvägledning',organization:'Akademikerförbundet SSR',detail:'Föreläsningen är listad i CV:t. Årtal anges inte för inspelningen.',url:'https://youtu.be/miktyqKtlLk'},
    {id:'ssr-visual',year:null,type:'Inspelad föreläsning',title:'Visuellt stöd och digitala verktyg i studie- och yrkesvägledning',organization:'Akademikerförbundet SSR',detail:'Föreläsningen är listad i CV:t. Årtal anges inte för inspelningen.',url:'https://youtu.be/O-b1Sfx_13o'}
  ],
  articles:[
    {title:'Vägledning är en mänsklig process, inte ett AI-experiment',url:'https://www.vilarare.se/vi-vagledare/ai/vagledning-ar-en-mansklig-process-inte-ett-ai-experiment/'},
    {title:'Tidningen Vägledaren – samlade artiklar',url:'https://drive.google.com/drive/folders/1JsyYYbJWEyqyJrp9UKlFfSY4TwHmDpiE?usp=sharing'},
    {title:'Artiklar om breddad rekrytering',url:'https://www.linkedin.com/in/joakimcao/recent-activity/articles/'},
    {title:'DigiSYV – nyhetsbrev och artiklar',url:'https://www.linkedin.com/newsletters/digisyv-nyhetsbrev-artiklar-7129141975206780928/'},
    {title:'Artiklar om karriär- och utbildningsfrågor',url:'https://www.linkedin.com/newsletters/7186024789642199040/'}
  ]
};
