// Google Translate's website service needs a public URL, not a local file.
// The discontinued Website Translator widget is deliberately not loaded.
window.JOAKIM_TRANSLATE = (() => {
  function publicWebsite(value){
    try{
      const url=new URL(value),host=url.hostname.toLowerCase();
      if(!['http:','https:'].includes(url.protocol)||url.username||url.password)return null;
      if(!host.includes('.')||host.endsWith('.local')||host.endsWith('.localhost')||host.startsWith('['))return null;
      if(/^(127|10|0)\./.test(host)||/^192\.168\./.test(host)||/^172\.(1[6-9]|2\d|3[01])\./.test(host)||/^169\.254\./.test(host))return null;
      url.hash='';url.search='';return url.href;
    }catch{return null;}
  }
  function link(value){const website=publicWebsite(value);return website?'https://translate.google.com/translate?sl=sv&tl=en&hl=en&u='+encodeURIComponent(website):null;}
  return {publicWebsite,link};
})();
