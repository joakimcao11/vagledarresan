window.SOURCE_DATA = {
  "events": [
    {
      "id": "event-0",
      "year": 2026,
      "title": "NUVAS Forum 2026, Köpenhamn, Danmark",
      "type": "Konferens / event"
    },
    {
      "id": "event-1",
      "year": 2026,
      "title": "Mötesplats arbetsmarknad GR 2026, Göteborg",
      "type": "Konferens / event"
    },
    {
      "id": "event-2",
      "year": 2026,
      "title": "Vejlederkonferencen 2026, Köpenhamn, Danmark",
      "type": "Konferens / event"
    },
    {
      "id": "event-3",
      "year": 2026,
      "title": "SETT-mässan 2026, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-4",
      "year": 2026,
      "title": "Sveriges Vägledarförening – webbinarium med det etiska rådet, 2026",
      "type": "Konferens / event"
    },
    {
      "id": "event-5",
      "year": 2026,
      "title": "Skolportens Vägledarkonferens 2026, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-6",
      "year": 2026,
      "title": "SYV-dagen 2026, Mälardalens universitet, Eskilstuna",
      "type": "Konferens / event"
    },
    {
      "id": "event-7",
      "year": 2025,
      "title": "Sveriges Vägledarkonferens 2025, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-8",
      "year": 2025,
      "title": "Vägledardagen 2025, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-9",
      "year": 2025,
      "title": "Vägledarkalendariet 2025, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-10",
      "year": 2025,
      "title": "Arbetsmarknadsdagarna via SKR 2025, Uppsala",
      "type": "Konferens / event"
    },
    {
      "id": "event-11",
      "year": 2025,
      "title": "Skånska SYV-dagen 2025, Lund",
      "type": "Konferens / event"
    },
    {
      "id": "event-12",
      "year": 2025,
      "title": "Utvecklingsingenjörskonferens 2025, BTH",
      "type": "Konferens / event"
    },
    {
      "id": "event-13",
      "year": 2025,
      "title": "Samba 13-konferencen 2025, Nyborg, Danmark",
      "type": "Konferens / event"
    },
    {
      "id": "event-14",
      "year": 2025,
      "title": "Skolriks 2025, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-15",
      "year": 2025,
      "title": "SETT-mässan 2025, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-16",
      "year": 2025,
      "title": "Skolverket 2025",
      "type": "Konferens / event"
    },
    {
      "id": "event-17",
      "year": 2025,
      "title": "SYV-Skåne nätverksdag 2025",
      "type": "Konferens / event"
    },
    {
      "id": "event-18",
      "year": 2025,
      "title": "Vägledardagen, Malmö universitet 2025",
      "type": "Konferens / event"
    },
    {
      "id": "event-19",
      "year": 2024,
      "title": "IAEVG International Conference 2024, Jyväskylä, Finland",
      "type": "Konferens / event"
    },
    {
      "id": "event-20",
      "year": 2024,
      "title": "UHR:s Kvalitetsdrivet-konferens 2024, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-21",
      "year": 2024,
      "title": "Skolportens Vägledarkonferens 2024, Göteborg",
      "type": "Konferens / event"
    },
    {
      "id": "event-22",
      "year": 2024,
      "title": "Sveriges Vägledarkonferens 2024, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-23",
      "year": 2024,
      "title": "Akademikerförbundet SSR 2024",
      "type": "Konferens / event"
    },
    {
      "id": "event-24",
      "year": 2024,
      "title": "Konferens för studievägledare inom svenska högskolor och universitet 2024",
      "type": "Konferens / event"
    },
    {
      "id": "event-25",
      "year": 2024,
      "title": "SiV – studievägledare inom vuxenutbildning 2024",
      "type": "Konferens / event"
    },
    {
      "id": "event-26",
      "year": 2024,
      "title": "Sveriges Lärare 2024",
      "type": "Konferens / event"
    },
    {
      "id": "event-27",
      "year": 2024,
      "title": "Utvecklingskonferens för Sveriges ingenjörsutbildning 2024, Chalmers",
      "type": "Konferens / event"
    },
    {
      "id": "event-28",
      "year": 2023,
      "title": "SiV – studievägledare inom Vuxenutbildning i Samverkan 2023",
      "type": "Konferens / event"
    },
    {
      "id": "event-29",
      "year": 2023,
      "title": "NUAS Discover Together Conference 2023, Uppsala",
      "type": "Konferens / event"
    },
    {
      "id": "event-30",
      "year": 2023,
      "title": "Sveriges Vägledarkonferens 2023, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-31",
      "year": 2022,
      "title": "Studievägledarkonferens 2022, Karlstads universitet",
      "type": "Konferens / event"
    },
    {
      "id": "event-32",
      "year": 2022,
      "title": "Vidareinformatörsdagen 2022, Högskolan i Borås",
      "type": "Konferens / event"
    },
    {
      "id": "event-33",
      "year": 2022,
      "title": "Sveriges Vägledarkonferens 2022, online",
      "type": "Konferens / event"
    },
    {
      "id": "event-34",
      "year": 2022,
      "title": "Utbildningskonferens 2022, SLU, Ultuna",
      "type": "Konferens / event"
    },
    {
      "id": "event-35",
      "year": 2022,
      "title": "Vägledarkalendariet 2022, Stockholm",
      "type": "Konferens / event"
    },
    {
      "id": "event-36",
      "year": 2021,
      "title": "Sveriges Vägledarkonferens 2021, online",
      "type": "Konferens / event"
    }
  ],
  "organizations": [
    {
      "id": "org-0",
      "name": "AcadeMedia Vägledning",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-1",
      "name": "Akademi Norr",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-2",
      "name": "Borås stad",
      "type": "Kommuner"
    },
    {
      "id": "org-3",
      "name": "Campus Mölndal",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-4",
      "name": "Dalavux",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-5",
      "name": "Falkenbergs kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-6",
      "name": "Familjen Helsingborg",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-7",
      "name": "GR, Göteborgsregionen",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-8",
      "name": "Göteborgs stad",
      "type": "Kommuner"
    },
    {
      "id": "org-9",
      "name": "Göteborgs universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-10",
      "name": "Halmstads stad",
      "type": "Kommuner"
    },
    {
      "id": "org-11",
      "name": "HejSYV AB",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-12",
      "name": "Helsingborgs stad",
      "type": "Kommuner"
    },
    {
      "id": "org-13",
      "name": "Humanistiska och teologiska fakulteterna, Lunds universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-14",
      "name": "Högskolan i Borås",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-15",
      "name": "Högskolan i Skövde",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-16",
      "name": "Karlshamns kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-17",
      "name": "Karlskronas kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-18",
      "name": "Karlstads universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-19",
      "name": "Kungsbacka kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-20",
      "name": "Laholms kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-21",
      "name": "Linköpings universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-22",
      "name": "LTH, Lunds universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-23",
      "name": "Luleå kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-24",
      "name": "Lunds universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-25",
      "name": "Malmö stad: grundskoleförvaltningen, gymnasie- och vuxenutbildningsförvaltningen samt arbetsmarknads- och socialförvaltningen",
      "type": "Kommuner"
    },
    {
      "id": "org-26",
      "name": "Malmö universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-27",
      "name": "Manpower Matchning",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-28",
      "name": "Medicinska fakulteten, Lunds universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-29",
      "name": "Mälardalens universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-30",
      "name": "Mölndals stad",
      "type": "Kommuner"
    },
    {
      "id": "org-31",
      "name": "Olofströms kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-32",
      "name": "Omställningsfonden",
      "type": "Organisationer och företag"
    },
    {
      "id": "org-33",
      "name": "Piteås kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-34",
      "name": "Region Blekinge",
      "type": "Regioner"
    },
    {
      "id": "org-35",
      "name": "Region Dalarna",
      "type": "Regioner"
    },
    {
      "id": "org-36",
      "name": "Region Skåne",
      "type": "Regioner"
    },
    {
      "id": "org-37",
      "name": "Region Sörmland",
      "type": "Regioner"
    },
    {
      "id": "org-38",
      "name": "Region Östergötland",
      "type": "Regioner"
    },
    {
      "id": "org-39",
      "name": "Ronneby kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-40",
      "name": "Skånes kommuner",
      "type": "Kommuner"
    },
    {
      "id": "org-41",
      "name": "SLU, Sveriges lantbruksuniversitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-42",
      "name": "Stockholms stad",
      "type": "Kommuner"
    },
    {
      "id": "org-43",
      "name": "Stockholms universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-44",
      "name": "Sundsvalls kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-45",
      "name": "Sölvesborgs kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-46",
      "name": "Umeås kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-47",
      "name": "Uppsala universitet",
      "type": "Universitet och högskolor"
    },
    {
      "id": "org-48",
      "name": "Uppsalas kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-49",
      "name": "Vara kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-50",
      "name": "Varbergs kommun",
      "type": "Kommuner"
    },
    {
      "id": "org-51",
      "name": "Västerås stads vuxenutbildning",
      "type": "Kommuner"
    }
  ],
  "lectureThemes": {
    "Digitalisering och AI": [
      "AI för studie- och yrkesvägledning i Komvux",
      "AI och chattbotar för studie- och yrkesvägledare",
      "AI och ChatGPT i studie- och yrkesvägledning",
      "AI i vägledning",
      "AI med skolpersonal",
      "Digitalt hopp – att arbeta med hopp och aktivt engagemang trots avstånd",
      "Digitala medier och etik i studie- och yrkesvägledning",
      "E-vägledning, IKT i vägledning och interaktiv vägledning",
      "Kreativa vägledningsmetoder och utveckling inom vägledning",
      "Så kan du använda AI i vägledningsarbetet",
      "Så kan du använda visuellt stöd och digitala verktyg i SYV",
      "Processvägledning i det digitala rummet",
      "Using digital technologies and creative approaches in career guidance counselling",
      "Visuellt stöd och digitala verktyg i studie- och yrkesvägledning"
    ],
    "Breddad rekrytering": [
      "Att intressera unga män för högre studier",
      "Att se studier som investering",
      "Sommarpraktik för killar – att intressera unga män för högre studier inom vård, omsorg och pedagogik"
    ],
    "Karriärlärande och unga vuxna": [
      "Att väcka viljan – när vägledande insatser blir en process av mening, riktning och framtidstro",
      "Hur får vi fler unga och vuxna människor att bidra till samhället och kompetensförsörjningen?",
      "På tal om karriärlärande och unga vuxna",
      "Vad händer när studie- och karriärvägledning blir något man gör, och inte bara får?"
    ]
  }
};
