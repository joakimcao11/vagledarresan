// Redigera innehåll här. Uppdragslistorna ligger separat i source-data.js.
window.JOAKIM_CONTENT = {
  character: { standing: 'assets/joakim-wave-v2.png', walking: 'assets/joakim-walk-v2.png', seated: 'assets/joakim-seat-v2.png' },
  contact: { email: 'info@digicao.nu', phone:'0707801645', website: 'https://digicao.nu', network: 'https://vagledarlabbet.se', linkedin: 'https://www.linkedin.com/in/joakimcao/recent-activity/articles/' },
  cv: { pdf: 'assets/CV-Joakim-Cao-VT2026.pdf' },
  route: [
    {city:'Malmö',country:'Sverige',mode:'car',environment:'malmo',area:null,note:'Välkommen ombord! Vi börjar hemma i Malmö och tar oss vidare till Lund.'},
    {city:'Lund',country:'Sverige',mode:'car',environment:'lund',area:'methods',note:'Nyfiken på hur jag arbetar? Öppna verktygslådan.'},
    {city:'Göteborg',country:'Sverige',mode:'train',environment:'coast',area:'perspectives',note:'Nu fortsätter vi norrut. Det finns en hel del att upptäcka längs vägen.'},
    {city:'Stockholm',country:'Sverige',mode:'train',environment:'stockholm',area:'assignments',note:'Här kan du utforska mina uppdrag, från 2021 till 2026.'},
    {city:'Västerås',country:'Sverige',mode:'train',environment:'vasteras',area:'partners',note:'Möten med olika verksamheter ger nya perspektiv.'},
    {city:'Uppsala',country:'Sverige',mode:'train',environment:'uppsala',area:'services',note:'Vad skulle passa din verksamhet? Utforska mina tjänster.'},
    {city:'Luleå',country:'Sverige',mode:'plane',environment:'north',area:'bio',note:'Nu lämnar vi marken och fortsätter resan norrut.'},
    {city:'Vasa',country:'Finland',mode:'plane',environment:'finland',area:'nordic',note:'Vägledning ser lite olika ut i olika länder. Det finns mycket att lära av varandra.'},
    {city:'Helsingfors',country:'Finland',mode:'train',environment:'helsinki',area:'finland',note:'Vilka perspektiv vill du ta med dig vidare?'},
    {city:'Köpenhamn',country:'Danmark',mode:'plane',environment:'copenhagen',area:'denmark',note:'Det är genom möten och samarbeten som många nya idéer växer fram.'},
    {city:'Nyborg',country:'Danmark',mode:'train',environment:'nyborg',area:'nyborg',note:'Ett sista stopp för nordiskt erfarenhetsutbyte.'},
    {city:'Målgång',country:'Dina upptäckter',mode:'walk',environment:'town',area:'finish',note:'Tack för att du följde med på resan!'}
  ],
  areas: [
    {id:'methods',number:'01',icon:'tool',title:'Mitt arbetssätt',subtitle:'Metoder som gör plats för reflektion.',color:'peach'},
    {id:'perspectives',number:'02',icon:'compass',title:'Mina perspektiv',subtitle:'Vägledning i en värld som förändras.',color:'sage'},
    {id:'assignments',number:'03',icon:'mic',title:'Uppdrag i urval',subtitle:'Konferenser, workshops och föreläsningar.',color:'yellow'},
    {id:'partners',number:'04',icon:'people',title:'I gott sällskap',subtitle:'Verksamheter jag har arbetat med.',color:'blue'},
    {id:'services',number:'05',icon:'spark',title:'Mina tjänster',subtitle:'Hitta ett upplägg för din verksamhet.',color:'peach'},
    {id:'bio',number:'06',icon:'person',title:'Om mig',subtitle:'Bakgrund, kompetens och engagemang.',color:'sage'}
  ],
  methods: [
    {id:'mi',title:'Motiverande samtal (MI)',what:'Ett samtalsinriktat förhållningssätt som utforskar motivation och personens egna skäl till förändring.',practice:'Ett möjligt upplägg är att utforska vad personen vill förändra och lyssna efter egna skäl att ta ett nästa steg.',where:'När ett val känns svårt eller motivationen behöver utforskas.',draft:true},
    {id:'solution',title:'Lösningsfokuserat arbetssätt',what:'Uppmärksammar resurser, undantag och små steg mot ett önskat läge.',practice:'Ett möjligt upplägg är att synliggöra det som redan fungerar och formulera ett hanterbart nästa steg.',where:'I samtal om mål, riktning och förändring.',draft:true},
    {id:'coaching',title:'Coaching',what:'Ett utforskande samtal med utrymme för egna mål, reflektion och handling.',practice:'Ett möjligt upplägg är att arbeta med frågor, återkoppling och uppföljning av personens egna mål.',where:'Vid utveckling av studiestrategier eller inför nya val.',draft:true},
    {id:'process',title:'Processvägledning',what:'Vägledning kan utvecklas över tid, genom flera tillfällen av reflektion och lärande.',practice:'I mitt föreläsningsutbud ingår processvägledning i det digitala rummet och karriärlärande som något man gör.',where:'När en verksamhet vill skapa kontinuitet i sitt vägledningsarbete.'},
    {id:'visual',title:'Kreativa och visuella metoder',what:'Bilder, visuella stöd och interaktiva verktyg kan ge fler sätt att uttrycka och utforska tankar.',practice:'Via DigiCao erbjuder jag kreativa och pedagogiska verktyg för vägledare, coacher och pedagoger.',where:'I individuella möten, gruppvägledning och kompetensutveckling.'},
    {id:'digilog',title:'Analog, digital och AI-stödd vägledning',what:'Digilogt arbete kombinerar digitala och analoga arbetssätt.',practice:'Jag arbetar digilogt i vägledningssamtal med unga och vuxna, inspirerat av pedagogen Helen Larsson.',where:'I vägledningssamtal och lärprocesser där olika uttryck och verktyg kompletterar varandra.'},
    {id:'career',title:'Karriärlärande',what:'Lärande som hjälper människor att utforska utbildning, arbetsliv och sina egna möjligheter.',practice:'Mina föreläsningar lyfter hur vägledning kan bli en process av mening, riktning och framtidstro.',where:'I arbetet med ungas och vuxnas utbildnings- och yrkesval.'}
  ],
  perspectives: [
    {id:'guidance',title:'Studie- och karriärvägledning',text:'Samtal med unga och vuxna inför framtida studie- och yrkesval.',example:'Utforska alternativ, formulera frågor och hitta ett nästa steg.',link:'Verksam studie- och karriärvägledare vid LTH, Lunds universitet.'},
    {id:'learning',title:'Karriärlärande och livslångt lärande',text:'Hur vägledning kan stärka lärande, riktning och framtidstro genom livet.',example:'Låt reflektion återkomma över tid i stället för att begränsas till ett enstaka samtal.',link:'Föreläsningsteman om karriärlärande och unga vuxna.'},
    {id:'ai',title:'Digitalisering och generativ AI',text:'Digitala verktygs möjligheter och utmaningar i vägledning och pedagogiskt arbete.',example:'Diskutera ett AI-genererat svar utifrån etik, relevans och professionellt omdöme.',link:'Föreläsningar och workshops om AI, ChatGPT och digitalisering.'},
    {id:'justice',title:'Social rättvisa och inkludering',text:'Meningsfulla lärprocesser där fler får möjlighet att delta och utvecklas.',example:'Granska vilka som nås av en insats och vilka som behöver andra former av stöd.',link:'Engagemang i social rättvisa, breddad rekrytering och breddat deltagande.'},
    {id:'future',title:'Framtidens arbetsliv',text:'Vad digitalisering och AI kan innebära för individer, organisationer och samhället.',example:'Utforska hur nya teknologier kan påverka yrkesroller och kompetensbehov.',link:'DigiCaos kunskapsarbete om digitaliseringens betydelse.'},
    {id:'education',title:'Utbildning och arbetsliv',text:'Samband mellan lärande, utbildningsval och möjligheter i arbetslivet.',example:'Diskutera utbildningsalternativ med utgångspunkt i personens frågor och mål.',link:'Kompetens inom pedagogik, arbetsvetenskap och vägledning.'},
    {id:'recruitment',title:'Breddad rekrytering',text:'Mer jämlika möjligheter att söka, delta i och fullfölja högre utbildning.',example:'Utforska vad som kan väcka intresse för högre studier hos grupper som är underrepresenterade.',link:'Föreläsningar om unga mäns intresse för högre studier och studier som investering.'},
    {id:'choices',title:'Ungas och vuxnas val',text:'Utbildnings- och yrkesval som en del av människors utveckling.',example:'Ge utrymme för både osäkerhet och nyfikenhet i samtal om framtiden.',link:'Vägledningssamtal och föreläsningar om mening, vilja och framtidstro.'},
    {id:'pedagogy',title:'Pedagogisk utveckling och lärande',text:'Verktyg och arbetssätt som stödjer reflektion, engagemang och lärande.',example:'Kombinera visuellt stöd med praktiska övningar och reflekterande samtal.',link:'Pedagogisk handledning, kreativa verktyg och utbildningsinsatser.'}
  ],
  services: [
    {id:'talk',title:'Föreläsningar och inspirationspass',text:'Perspektiv och praktiska exempel på vägledning, AI och digitalisering.',audience:'Vägledare, pedagoger, chefer och konferensarrangörer.',format:'Små eller stora grupper, på plats eller online.',needs:['speaker','ai'],confirmed:true},
    {id:'workshop',title:'Workshops och kompetensutveckling',text:'Praktiskt arbete med kreativa metoder och digitala verktyg.',audience:'Studie- och yrkesvägledare, coacher och pedagoger.',format:'Workshop eller utbildningsinsats anpassad efter målgrupp och syfte.',needs:['workshop','guidance','ai'],confirmed:true},
    {id:'syv',title:'Utbildning för vägledare',text:'Utveckla vägledningsarbetet med modern teknik och pedagogiska verktyg.',audience:'Yrkesverksamma vägledare och SYV-studenter.',format:'Föreläsningar, workshops och instruktionsfilmer.',needs:['guidance','workshop'],confirmed:true},
    {id:'ai',title:'Generativ AI i praktiken',text:'Utforska AI i vägledande och pedagogiskt arbete med ett etiskt och kritiskt förhållningssätt.',audience:'Vägledare, lärare och andra som arbetar med utbildning.',format:'Föreläsning, workshop eller konsultation.',needs:['ai','speaker','workshop'],confirmed:true},
    {id:'tools',title:'Digitala och pedagogiska verktyg',text:'Kreativa verktyg som kombinerar digitala och analoga arbetssätt.',audience:'Vägledare, coacher och pedagoger.',format:'Verktyg, instruktionsfilmer, konsultation och stöttning.',needs:['tools','guidance'],confirmed:true},
    {id:'process',title:'Processtöd och verksamhetsutveckling',text:'Pedagogisk handledning och stöd i utvecklingsarbete.',audience:'Grupper och enskilda personer i utbildningsverksamheter.',format:'Upplägg och omfattning behöver beskrivas vidare tillsammans.',needs:['guidance','tools'],confirmed:true},
    {id:'tailored',title:'Skräddarsydda utbildningsupplägg',text:'Alla uppdrag anpassas efter målgrupp, syfte, format och tidsomfattning.',audience:'Verksamheter som vill forma en insats utifrån sina egna behov.',format:'Enstaka timmar, halvdag, heldag eller överenskommet upplägg. Tydlig offert i förväg.',needs:['ai','guidance','speaker','workshop','tools'],confirmed:true}
  ],
  bio: {
    intro:'Jag heter Joakim Cao och arbetar med vägledning, lärande och utveckling. Jag är studie- och karriärvägledare vid LTH, Lunds universitet, och pedagogisk utvecklare via DigiCao.',
    background:'Min utbildningsresa vid Malmö universitet började med studie- och yrkesvägledarexamen 2017. År 2021 tog jag en magisterexamen i pedagogik med inriktning mot karriärlärande och övergångar. År 2025 kompletterade jag med master i pedagogik, magister i arbetsvetenskap och en handledarkurs.',
    competence:'Vägledning, karriärlärande, pedagogik, digitalisering och generativ AI. Vid LTH arbetar jag också med akademisk mottagning, VFU-handledning, studentambassadörsutbildning, mastervägledning och strategiskt karriärstöd.',
    engagement:'Jag är engagerad i breddad rekrytering, breddat deltagande, social rättvisa och frågor om unga och vuxnas lärande. Jag är också redaktör för Tidningen Vägledaren via Sveriges Vägledarförening.',
    timeline:[{year:'2016–2018',text:'Vägledningsarbete vid Merit utbildning AB och Peab AB samt karriärcoachning och rekrytering vid Jobbklar AB.'},{year:'2017',text:'Studie- och yrkesvägledarexamen vid Malmö universitet.'},{year:'2018–2022',text:'Studie- och karriärvägledning vid Malmö universitet; även projektledning inom breddad rekrytering 2019–2022.'},{year:'2020–',text:'Pedagogisk utvecklare, föreläsare och utbildningskonsult genom DigiCao.'},{year:'2021',text:'Magister i pedagogik med inriktning mot karriärlärande och övergångar.'},{year:'2022–',text:'Studie- och karriärvägledare vid LTH, Lunds universitet.'},{year:'2023–',text:'Redaktör och skribent för Tidningen Vägledaren via Sveriges Vägledarförening.'},{year:'2025',text:'Master i pedagogik, magister i arbetsvetenskap och handledarkurs vid Malmö universitet.'},{year:'2026–',text:'Driver Vägledarlabbet, ett nätverk för vägledare.'}]
  }
};
